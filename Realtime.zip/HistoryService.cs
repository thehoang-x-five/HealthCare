using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HealthCare.Datas;
using HealthCare.DTOs;
using HealthCare.Entities;
using HealthCare.Realtime;
using HealthCare.RenderID;
using Microsoft.EntityFrameworkCore;

namespace HealthCare.Services
{
    public class HistoryService(DataContext db, IRealtimeService realtime) : IHistoryService
    {
        private readonly DataContext _db = db;
        private readonly IRealtimeService _realtime=realtime;

        // ==================== LIST LỊCH SỬ KHÁM (TAB "KHÁM BỆNH") ====================

        public async Task<PagedResult<HistoryVisitRecordDto>> LayLichSuAsync(HistoryFilterRequest filter)
        {
            var q = _db.LuotKhamBenhs
                .AsNoTracking()
                .Include(l => l.HangDoi)
                    .ThenInclude(h => h.BenhNhan)
                .Include(l => l.HangDoi)
                    .ThenInclude(h => h.Phong)
                        .ThenInclude(p => p.KhoaChuyenMon)
                .Include(l => l.NhanSuThucHien) // bác sĩ thực hiện
                .Include(l => l.HangDoi)
                    .ThenInclude(h => h.PhieuKhamLamSang)
                        .ThenInclude(pk => pk.PhieuChanDoanCuoi)
                .Include(l => l.HangDoi)
                    .ThenInclude(h => h.PhieuKhamLamSang)
                        .ThenInclude(pk => pk.DichVuKham)
                .AsQueryable();

            // ----- scope: hôm nay / khoảng thời gian -----
            DateTime? from = filter.FromTime;
            DateTime? to = filter.ToTime;

            if (filter.OnlyToday == true)
            {
                var today = DateTime.Today;
                from = today;
                to = today.AddDays(1).AddTicks(-1);
            }

            if (from.HasValue)
            {
                q = q.Where(l => l.ThoiGianBatDau >= from.Value);
            }

            if (to.HasValue)
            {
                q = q.Where(l => l.ThoiGianBatDau <= to.Value);
            }

            // ----- theo bệnh nhân -----
            if (!string.IsNullOrWhiteSpace(filter.MaBenhNhan))
            {
                var maBn = filter.MaBenhNhan.Trim();
                q = q.Where(l => l.HangDoi.MaBenhNhan == maBn);
            }

            // ----- loại lượt: clinic / service (dựa vào loại phòng) -----
            if (!string.IsNullOrWhiteSpace(filter.LoaiLuot) &&
                !string.Equals(filter.LoaiLuot, "all", StringComparison.OrdinalIgnoreCase))
            {
                bool isService = string.Equals(filter.LoaiLuot, "service", StringComparison.OrdinalIgnoreCase);
                q = q.Where(l =>
                    (l.HangDoi.Phong.LoaiPhong == "phong_dich_vu") == isService);
            }

            // ----- keyword toàn văn -----
            if (!string.IsNullOrWhiteSpace(filter.Keyword))
            {
                var kw = filter.Keyword.Trim();

                q = q.Where(l =>
                    l.HangDoi.BenhNhan.HoTen.Contains(kw) ||
                    l.HangDoi.BenhNhan.MaBenhNhan.Contains(kw) ||
                    (l.NhanSuThucHien != null && l.NhanSuThucHien.HoTen.Contains(kw)) ||
                    (l.HangDoi.Phong.KhoaChuyenMon.TenKhoa.Contains(kw)) ||
                    (l.HangDoi.PhieuKhamLamSang != null &&
                        (l.HangDoi.PhieuKhamLamSang.TrieuChung ?? "").Contains(kw)) ||
                    (l.HangDoi.PhieuKhamLamSang != null &&
                        l.HangDoi.PhieuKhamLamSang.PhieuChanDoanCuoi != null &&
                        ((l.HangDoi.PhieuKhamLamSang.PhieuChanDoanCuoi.ChanDoanCuoi ?? "")
                            .Contains(kw))));
            }

            // ----- phân trang -----
            var page = filter.Page <= 0 ? 1 : filter.Page;
            var pageSize = filter.PageSize <= 0 ? 50 : filter.PageSize;

            var totalItems = await q.CountAsync();

            var data = await q
                .OrderByDescending(l => l.ThoiGianBatDau)
                .ThenByDescending(l => l.MaLuotKham)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            var items = data.Select(MapToVisitRecord).ToList();

            return new PagedResult<HistoryVisitRecordDto>
            {
                Items = items,
                TotalItems = totalItems,
                Page = page,
                PageSize = pageSize
            };
        }

        // ==================== CHI TIẾT 1 LẦN KHÁM ====================

        public async Task<HistoryVisitDetailDto?> LayChiTietLichSuKhamAsync(string maLuotKham)
        {
            var luot = await _db.LuotKhamBenhs
                .Include(l => l.HangDoi)
                    .ThenInclude(h => h.BenhNhan)
                .Include(l => l.HangDoi)
                    .ThenInclude(h => h.Phong)
                        .ThenInclude(p => p.KhoaChuyenMon)
                .Include(l => l.NhanSuThucHien)
                .Include(l => l.HangDoi)
                    .ThenInclude(h => h.PhieuKhamLamSang)
                        .ThenInclude(pk => pk.DichVuKham)
                .Include(l => l.HangDoi)
                    .ThenInclude(h => h.PhieuKhamLamSang)
                        .ThenInclude(pk => pk.PhieuChanDoanCuoi)
                .Include(l => l.HangDoi)
                    .ThenInclude(h => h.PhieuKhamLamSang)
                        .ThenInclude(pk => pk.PhieuKhamCanLamSang)
                            .ThenInclude(cls => cls.ChiTietDichVus)
                                .ThenInclude(ct => ct.DichVuYTe)
                .Include(l => l.HangDoi)
                    .ThenInclude(h => h.PhieuKhamLamSang)
                        .ThenInclude(pk => pk.PhieuKhamCanLamSang)
                            .ThenInclude(cls => cls.ChiTietDichVus)
                                .ThenInclude(ct => ct.KetQuaDichVu)
                .FirstOrDefaultAsync(l => l.MaLuotKham == maLuotKham);

            if (luot == null)
                return null;

            var h = luot.HangDoi;
            var bn = h.BenhNhan;
            var phong = h.Phong;
            var khoa = phong.KhoaChuyenMon;
            var bs = luot.NhanSuThucHien;
            var phieuLs = h.PhieuKhamLamSang;
            var pcd = phieuLs?.PhieuChanDoanCuoi;
            var phieuCls = phieuLs?.PhieuKhamCanLamSang;
            var phieuTongHop = phieuLs?.PhieuTongHopKetQua ?? phieuCls?.PhieuTongHopKetQua;

            bool laDichVu = phong.LoaiPhong == "phong_dich_vu";

            // Exam rows (tóm tắt khám)
            var examRows = new List<HistoryExamRowDto>();
            if (pcd != null)
            {
                if (!string.IsNullOrWhiteSpace(pcd.NoiDungKham))
                {
                    examRows.Add(new HistoryExamRowDto
                    {
                        Label = "Nội dung khám",
                        Value = pcd.NoiDungKham
                    });
                }
                if (!string.IsNullOrWhiteSpace(pcd.HuongXuTri))
                {
                    examRows.Add(new HistoryExamRowDto
                    {
                        Label = "Hướng xử trí",
                        Value = pcd.HuongXuTri
                    });
                }
            }

            // Dịch vụ CLS
            var services = new List<HistoryServiceResultDto>();
            if (phieuCls != null)
            {
                foreach (var ct in phieuCls.ChiTietDichVus)
                {
                    var dv = ct.DichVuYTe;
                    var kq = ct.KetQuaDichVu;

                    services.Add(new HistoryServiceResultDto
                    {
                        MaDichVu = dv.MaDichVu,
                        TenDichVu = dv.TenDichVu,
                        KetQua = kq?.NoiDungKetQua,
                        DonGia = dv.DonGia
                    });
                }
            }

            // Chẩn đoán
            HistoryDiagnosisDto? diag = null;
            if (pcd != null)
            {
                diag = new HistoryDiagnosisDto
                {
                    ChanDoanSoBo = pcd.ChanDoanSoBo,
                    ChanDoanXacDinh = pcd.ChanDoanCuoi,
                    PhacDoDieuTri = pcd.PhatDoDieuTri,
                    TuVanDanDo = pcd.LoiKhuyen
                };
            }

            var dto = new HistoryVisitDetailDto
            {
                ThoiGian = luot.ThoiGianBatDau,
                MaBenhNhan = bn.MaBenhNhan,
                TenBenhNhan = bn.HoTen,
                MaKhoa = khoa.MaKhoa,
                TenKhoa = khoa.TenKhoa,
                MaBacSi = bs?.MaNhanVien,
                TenBacSi = bs?.HoTen,
                LoaiLuot = laDichVu ? "service" : "clinic",
                LaKhamDichVu = laDichVu,
                TomTatKham = pcd?.NoiDungKham ?? phieuLs?.TrieuChung,

                MaLuotKham = luot.MaLuotKham,
                MaPhieuKhamLs = phieuLs?.MaPhieuKham,
                MaPhieuKhamCls = phieuCls?.MaPhieuKhamCls,
                MaPhieuTongHopCls = phieuTongHop?.MaPhieuTongHop,
                MaPhieuChanDoanCuoi = pcd?.MaPhieuChanDoan,
                MaDonThuoc = pcd?.MaDonThuoc,

                KetQuaKham = examRows,
                KetQuaDichVu = services,
                ChanDoan = diag
            };

            return dto;
        }

        public async Task<HistoryVisitRecordDto> TaoLuotKhamAsync(HistoryVisitCreateRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.MaHangDoi))
                throw new ArgumentException("MaHangDoi là bắt buộc", nameof(request.MaHangDoi));

            if (string.IsNullOrWhiteSpace(request.LoaiLuot))
                throw new ArgumentException("LoaiLuot là bắt buộc (kham_moi / tai_kham)", nameof(request.LoaiLuot));

            // Tìm hàng đợi tương ứng
            var hangDoi = await _db.HangDois    
                .Include(h => h.BenhNhan)
                .Include(h => h.Phong)
                    .ThenInclude(p => p.KhoaChuyenMon)
                .Include(h => h.PhieuKhamLamSang)
                .FirstOrDefaultAsync(h => h.MaHangDoi == request.MaHangDoi);

            if (hangDoi is null)
                throw new KeyNotFoundException($"Không tìm thấy hàng đợi {request.MaHangDoi}");

            // Tìm nhân sự thực hiện (bác sĩ / điều dưỡng chính)
            NhanVienYTe? nhanSu = null;                
            if (!string.IsNullOrWhiteSpace(request.MaNhanSuThucHien))
            {
                nhanSu = await _db.NhanVienYTes        
                    .FirstOrDefaultAsync(n => n.MaNhanVien == request.MaNhanSuThucHien);

                if (nhanSu is null)
                    throw new ArgumentException("Không tìm thấy nhân sự thực hiện", nameof(request.MaNhanSuThucHien));
            }

            var now = DateTime.Now;
            var batDau = request.ThoiGianBatDau ?? now;

            // Nếu được truyền sẵn thời gian kết thúc + trạng thái hoàn tất thì lưu luôn, không thì để null
            DateTime? ketThuc = request.ThoiGianKetThuc;

            var entity = new LuotKhamBenh
            {
                MaLuotKham = GeneratorID.NewLuotKhamId(),
                MaHangDoi = hangDoi.MaHangDoi,

                MaNhanSuThucHien = nhanSu?.MaNhanVien,     
                MaYTaHoTro = request.MaYTaHoTro,  

                ThoiGianBatDau = batDau,
                ThoiGianKetThuc = ketThuc,

                // Loại lượt: kham_moi / tai_kham (theo yêu cầu anh)
                LoaiLuot = request.LoaiLuot,

                // Trạng thái: dang_kham / hoan_tat (hoặc các trạng thái khác nếu anh muốn)
                TrangThai = string.IsNullOrWhiteSpace(request.TrangThai)
                                      ? "dang_kham"
                                      : request.TrangThai,

            };

            _db.LuotKhamBenhs.Add(entity);
            await _db.SaveChangesAsync();

            // Reload đầy đủ nav giống LayLichSuAsync để map DTO
            var saved = await _db.LuotKhamBenhs
                .Include(l => l.HangDoi)
                    .ThenInclude(h => h.BenhNhan)
                .Include(l => l.HangDoi)
                    .ThenInclude(h => h.Phong)
                        .ThenInclude(p => p.KhoaChuyenMon)
                .Include(l => l.NhanSuThucHien)
                .Include(l => l.HangDoi)
                    .ThenInclude(h => h.PhieuKhamLamSang)
                        .ThenInclude(pk => pk.PhieuChanDoanCuoi)
                .Include(l => l.HangDoi)
                    .ThenInclude(h => h.PhieuKhamLamSang)
                        .ThenInclude(pk => pk.DichVuKham)
                .FirstAsync(l => l.MaLuotKham == entity.MaLuotKham);

            var dto = MapToVisitRecord(saved);

            // realtime cho staff (bác sĩ + y tá)
            await _realtime.BroadcastVisitCreatedAsync(dto);

            return dto;
        }
        // ==================== CẬP NHẬT TRẠNG THÁI LƯỢT KHÁM ====================

        public async Task<HistoryVisitRecordDto?> CapNhatTrangThaiLuotKhamAsync(
            string maLuotKham,
            HistoryVisitStatusUpdateRequest request)
        {
            var luot = await _db.LuotKhamBenhs
                .Include(l => l.HangDoi)
                    .ThenInclude(h => h.BenhNhan)
                .Include(l => l.HangDoi)
                    .ThenInclude(h => h.Phong)
                        .ThenInclude(p => p.KhoaChuyenMon)
                .Include(l => l.NhanSuThucHien)
                .Include(l => l.HangDoi)
                    .ThenInclude(h => h.PhieuKhamLamSang)
                        .ThenInclude(pk => pk.DichVuKham)
                .Include(l => l.HangDoi)
                    .ThenInclude(h => h.PhieuKhamLamSang)
                        .ThenInclude(pk => pk.PhieuChanDoanCuoi)
                .FirstOrDefaultAsync(l => l.MaLuotKham == maLuotKham);

            if (luot is null)
                return null;

            // Cập nhật trạng thái
            if (!string.IsNullOrWhiteSpace(request.TrangThai))
            {
                luot.TrangThai = request.TrangThai;
            }

            // Cập nhật thời gian kết thúc nếu cần
            if (request.ThoiGianKetThuc.HasValue)
            {
                luot.ThoiGianKetThuc = request.ThoiGianKetThuc.Value;
            }
            else if (string.Equals(request.TrangThai, "da_hoan_tat", StringComparison.OrdinalIgnoreCase) ||
                     string.Equals(request.TrangThai, "da_huy", StringComparison.OrdinalIgnoreCase))
            {
                // Nếu chuyển sang trạng thái kết thúc mà chưa có time -> set now
                luot.ThoiGianKetThuc ??= DateTime.Now;
            }

            await _db.SaveChangesAsync();

            var dto = MapToVisitRecord(luot);

            await _realtime.BroadcastVisitStatusUpdatedAsync(dto);

            return dto;
        }


        // ==================== MAPPING LIST RECORD ====================

        private static HistoryVisitRecordDto MapToVisitRecord(LuotKhamBenh luot)
        {
            var h = luot.HangDoi;
            var bn = h.BenhNhan;
            var phong = h.Phong;
            var khoa = phong.KhoaChuyenMon;
            var bs = luot.NhanSuThucHien;
            var phieuLs = h.PhieuKhamLamSang;
            var pcd = phieuLs?.PhieuChanDoanCuoi;
            var phieuCls = phieuLs?.PhieuKhamCanLamSang;
            var phieuTongHop = phieuLs?.PhieuTongHopKetQua ?? phieuCls?.PhieuTongHopKetQua;

            bool laDichVu = phong.LoaiPhong == "phong_dich_vu";
            string loaiLuot = laDichVu ? "service" : "clinic";

            string? note = pcd?.ChanDoanCuoi
                           ?? pcd?.NoiDungKham
                           ?? phieuLs?.TrieuChung;

            return new HistoryVisitRecordDto
            {
                ThoiGian = luot.ThoiGianBatDau,

                MaBenhNhan = bn.MaBenhNhan,
                TenBenhNhan = bn.HoTen,

                MaKhoa = khoa.MaKhoa,
                TenKhoa = khoa.TenKhoa,

                MaBacSi = bs?.MaNhanVien,
                TenBacSi = bs?.HoTen,

                LoaiLuot = loaiLuot,
                GhiChu = note,
                LaKhamDichVu = laDichVu,

                MaLuotKham = luot.MaLuotKham,
                MaPhieuKhamLs = phieuLs?.MaPhieuKham,
                MaPhieuKhamCls = phieuCls?.MaPhieuKhamCls,
                MaPhieuTongHopCls = phieuTongHop?.MaPhieuTongHop,
                MaPhieuChanDoanCuoi = pcd?.MaPhieuChanDoan,
                MaDonThuoc = pcd?.MaDonThuoc
            };
        }
    }
}
