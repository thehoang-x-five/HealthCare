﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using HealthCare.Datas;
using HealthCare.DTOs;
using HealthCare.Entities;
using Microsoft.EntityFrameworkCore;
using HealthCare.Realtime;
namespace HealthCare.Services
{
    /// <summary>
    /// Service quản lý phiếu CLS, chi tiết DV, kết quả và phiếu tổng hợp.
    /// </summary>
    public class ClsService(DataContext db, IRealtimeService realtime) : IClsService
    {
        private readonly DataContext _db = db;
        private readonly IRealtimeService _realtime = realtime;
        // ================== HELPER ==================

        private static string? BuildThongTinChiTiet(BenhNhan bn)
        {
            var parts = new List<string>();

            void Add(string label, string? value)
            {
                if (!string.IsNullOrWhiteSpace(value))
                    parts.Add($"{label}: {value}");
            }

            Add("Dị ứng", bn.DiUng);
            Add("Chống chỉ định", bn.ChongChiDinh);
            Add("Thuốc đang dùng", bn.ThuocDangDung);
            Add("Tiền sử bệnh", bn.TieuSuBenh);
            Add("Tiền sử phẫu thuật", bn.TienSuPhauThuat);
            Add("Nhóm máu", bn.NhomMau);
            Add("Bệnh mạn tính", bn.BenhManTinh);
            Add("Sinh hiệu", bn.SinhHieu);

            return parts.Count == 0 ? null : string.Join(" | ", parts);
        }

        private static ClsItemDto MapClsItem(ChiTietDichVu c)
        {
            var dv = c.DichVuYTe;

            return new ClsItemDto
            {
                MaChiTietDv = c.MaChiTietDv,
                MaPhieuKhamCls = c.MaPhieuKhamCls,
                MaDichVu = c.MaDichVu,
                TenDichVu = dv?.TenDichVu ?? "",
                LoaiDichVu = dv?.LoaiDichVu ?? "",
                PhiDV = dv?.DonGia.ToString("0") ?? "0",
                GhiChu = c.GhiChu,
                TrangThai = c.TrangThai == "da_hoan_tat" ? "da_co_ket_qua" : "chua_co_ket_qua"
            };
        }

        private async Task<ClsOrderDto?> BuildClsOrderDtoAsync(string maPhieuKhamCls)
        {
            var row =
                await (from cls in _db.PhieuKhamCanLamSangs.AsNoTracking()
                       join ls in _db.PhieuKhamLamSangs.AsNoTracking()
                           on cls.MaPhieuKhamLs equals ls.MaPhieuKham
                       join bn in _db.BenhNhans.AsNoTracking()
                           on ls.MaBenhNhan equals bn.MaBenhNhan
                       where cls.MaPhieuKhamCls == maPhieuKhamCls
                       select new { cls, ls, bn })
                .FirstOrDefaultAsync();

            if (row is null) return null;

            var chiTietList = await _db.ChiTietDichVus
                .AsNoTracking()
                .Where(c => c.MaPhieuKhamCls == maPhieuKhamCls)
                .Include(c => c.DichVuYTe)
                .ToListAsync();

            var itemDtos = chiTietList.Select(MapClsItem).ToList();

            var firstDv = chiTietList.FirstOrDefault()?.DichVuYTe;
            var maPhong = firstDv?.MaPhongThucHien ?? "";

            return new ClsOrderDto
            {
                MaPhieuKhamCls = row.cls.MaPhieuKhamCls,
                MaPhieuKhamLs = row.cls.MaPhieuKhamLs,
                MaBenhNhan = row.bn.MaBenhNhan,

                HoTen = row.bn.HoTen,
                TenBenhNhan = row.bn.HoTen,
                NgaySinh = row.bn.NgaySinh,
                GioiTinh = row.bn.GioiTinh,
                DienThoai = row.bn.DienThoai,
                Email = row.bn.Email,
                DiaChi = row.bn.DiaChi,

                TrangThai = row.cls.TrangThai,
                AutoPublishEnabled = row.cls.AutoPublishEnabled,
                GhiChu = row.cls.GhiChu,
                NgayLap = row.cls.NgayGioLap,
                GioLap = row.cls.NgayGioLap.TimeOfDay,

                MaKhoa = "",
                TenKhoa = null,
                MaPhong = maPhong,
                TenPhong = null,

                MaNguoiLap = row.ls.MaNguoiLap,
                TenNguoiLap = null,

                ThongTinChiTiet = BuildThongTinChiTiet(row.bn),
                ListItemDV = itemDtos
            };
        }

        // ================== 1. PHIẾU CLS ==================

        public async Task<ClsOrderDto> TaoPhieuClsAsync(ClsOrderCreateRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.MaBenhNhan))
                throw new ArgumentException("MaBenhNhan là bắt buộc");
            if (string.IsNullOrWhiteSpace(request.MaPhieuKhamLs))
                throw new ArgumentException("MaPhieuKhamLs là bắt buộc");
            if (string.IsNullOrWhiteSpace(request.MaNguoiLap))
                throw new ArgumentException("MaNguoiLap là bắt buộc");

            var phieuLs = await _db.PhieuKhamLamSangs
                .Include(p => p.BenhNhan)
                .Include(p => p.DichVuKham)
                .FirstOrDefaultAsync(p =>
                    p.MaPhieuKham == request.MaPhieuKhamLs &&
                    p.MaBenhNhan == request.MaBenhNhan) ?? throw new InvalidOperationException("Không tìm thấy phiếu khám LS tương ứng");
            var now = DateTime.Now;

            var phieuCls = new PhieuKhamCanLamSang
            {
                MaPhieuKhamCls = $"CLS-{Guid.NewGuid():N}",
                MaPhieuKhamLs = phieuLs.MaPhieuKham,
                NgayGioLap = now,
                AutoPublishEnabled = request.AutoPublishEnabled,
                TrangThai = request.TrangThai ?? "da_lap",
                GhiChu = request.GhiChu
            };

            _db.PhieuKhamCanLamSangs.Add(phieuCls);
            await _db.SaveChangesAsync();

            // Tạo danh sách chi tiết DV nếu có
            if (request.ListItemDV is not null && request.ListItemDV.Count > 0)
            {
                foreach (var item in request.ListItemDV)
                {
                    var createReq = new ClsItemCreateRequest
                    {
                        MaPhieuKhamCls = phieuCls.MaPhieuKhamCls,
                        MaDichVu = item.MaDichVu,
                        GhiChu = item.GhiChu,
                        TrangThai = "chua_co_ket_qua"
                    };
                    await TaoChiTietDichVuAsync(createReq);
                }
            }

           
            var dto = await BuildClsOrderDtoAsync(phieuCls.MaPhieuKhamCls)
          ?? throw new InvalidOperationException("Không build được DTO CLS");

            // Realtime: phiếu CLS mới
            await _realtime.BroadcastClsOrderCreatedAsync(dto);

            return dto;
        }

        public Task<ClsOrderDto?> LayPhieuClsAsync(string maPhieuKhamCls)
        {
            if (string.IsNullOrWhiteSpace(maPhieuKhamCls))
                return Task.FromResult<ClsOrderDto?>(null);

            return BuildClsOrderDtoAsync(maPhieuKhamCls);
        }

        public async Task<ClsOrderDto?> CapNhatTrangThaiPhieuClsAsync(string maPhieuKhamCls, string trangThai)
        {
            if (string.IsNullOrWhiteSpace(maPhieuKhamCls))
                return null;
            if (string.IsNullOrWhiteSpace(trangThai))
                throw new ArgumentException("TrangThai là bắt buộc");

            var phieu = await _db.PhieuKhamCanLamSangs
                .FirstOrDefaultAsync(p => p.MaPhieuKhamCls == maPhieuKhamCls);

            if (phieu is null) return null;

            phieu.TrangThai = trangThai;
            await _db.SaveChangesAsync();

            var dto = await BuildClsOrderDtoAsync(maPhieuKhamCls);

            if (dto is not null)
            {
                // Realtime: cập nhật trạng thái phiếu CLS
                await _realtime.BroadcastClsOrderStatusUpdatedAsync(dto);
            }

            return dto;
        }

        // ================== 2. SEARCH + PAGING PHIẾU CLS ==================

        public async Task<PagedResult<ClsOrderDto>> TimKiemPhieuClsAsync(
            string? maBenhNhan,
            string? maBacSi,
            DateTime? fromDate,
            DateTime? toDate,
            string? trangThai,
            int page,
            int pageSize)
        {
            page = page <= 0 ? 1 : page;
            pageSize = pageSize <= 0 ? 20 : pageSize;

            var query =
                from cls in _db.PhieuKhamCanLamSangs.AsNoTracking()
                join ls in _db.PhieuKhamLamSangs.AsNoTracking()
                    on cls.MaPhieuKhamLs equals ls.MaPhieuKham
                join bn in _db.BenhNhans.AsNoTracking()
                    on ls.MaBenhNhan equals bn.MaBenhNhan
                select new { cls, ls, bn };

            if (!string.IsNullOrWhiteSpace(maBenhNhan))
                query = query.Where(x => x.bn.MaBenhNhan == maBenhNhan);

            if (!string.IsNullOrWhiteSpace(maBacSi))
                query = query.Where(x => x.ls.MaBacSiKham == maBacSi);

            if (fromDate.HasValue)
            {
                var from = fromDate.Value.Date;
                query = query.Where(x => x.cls.NgayGioLap >= from);
            }

            if (toDate.HasValue)
            {
                var to = toDate.Value.Date.AddDays(1);
                query = query.Where(x => x.cls.NgayGioLap < to);
            }

            if (!string.IsNullOrWhiteSpace(trangThai))
                query = query.Where(x => x.cls.TrangThai == trangThai);

            query = query.OrderByDescending(x => x.cls.NgayGioLap);

            var totalItems = await query.CountAsync();
            var pageData = await query
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            var maClsList = pageData.Select(x => x.cls.MaPhieuKhamCls).ToList();

            var itemsByHeader = await _db.ChiTietDichVus
                .AsNoTracking()
                .Where(c => maClsList.Contains(c.MaPhieuKhamCls))
                .Include(c => c.DichVuYTe)
                .GroupBy(c => c.MaPhieuKhamCls)
                .ToDictionaryAsync(g => g.Key, g => g.ToList());

            var dtos = new List<ClsOrderDto>();

            foreach (var row in pageData)
            {
                itemsByHeader.TryGetValue(row.cls.MaPhieuKhamCls, out var list);
                var itemDtos = (list ?? [])
                    .Select(MapClsItem)
                    .ToList();

                var firstDv = (list ?? [])
                    .FirstOrDefault()?.DichVuYTe;
                var maPhong = firstDv?.MaPhongThucHien ?? "";

                dtos.Add(new ClsOrderDto
                {
                    MaPhieuKhamCls = row.cls.MaPhieuKhamCls,
                    MaPhieuKhamLs = row.cls.MaPhieuKhamLs,
                    MaBenhNhan = row.bn.MaBenhNhan,

                    HoTen = row.bn.HoTen,
                    TenBenhNhan = row.bn.HoTen,
                    NgaySinh = row.bn.NgaySinh,
                    GioiTinh = row.bn.GioiTinh,
                    DienThoai = row.bn.DienThoai,
                    Email = row.bn.Email,
                    DiaChi = row.bn.DiaChi,

                    TrangThai = row.cls.TrangThai,
                    AutoPublishEnabled = row.cls.AutoPublishEnabled,
                    GhiChu = row.cls.GhiChu,
                    NgayLap = row.cls.NgayGioLap,
                    GioLap = row.cls.NgayGioLap.TimeOfDay,

                    MaKhoa = "",
                    TenKhoa = null,
                    MaPhong = maPhong,
                    TenPhong = null,

                    MaNguoiLap = row.ls.MaNguoiLap,
                    TenNguoiLap = null,

                    ThongTinChiTiet = BuildThongTinChiTiet(row.bn),
                    ListItemDV = itemDtos
                });
            }

            return new PagedResult<ClsOrderDto>
            {
                Items = dtos,
                TotalItems = totalItems,
                Page = page,
                PageSize = pageSize
            };
        }

        // ================== 3. CHI TIẾT DỊCH VỤ ==================

        public async Task<ClsItemDto> TaoChiTietDichVuAsync(ClsItemCreateRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.MaPhieuKhamCls))
                throw new ArgumentException("MaPhieuKhamCls là bắt buộc");
            if (string.IsNullOrWhiteSpace(request.MaDichVu))
                throw new ArgumentException("MaDichVu là bắt buộc");

            var headerExists = await _db.PhieuKhamCanLamSangs
                .AnyAsync(p => p.MaPhieuKhamCls == request.MaPhieuKhamCls);

            if (!headerExists)
                throw new InvalidOperationException("Không tìm thấy phiếu CLS");

            var dichVu = await _db.DichVuYTes
                .FirstOrDefaultAsync(d => d.MaDichVu == request.MaDichVu)
                    ?? throw new InvalidOperationException("Không tìm thấy dịch vụ CLS");

            var chiTiet = new ChiTietDichVu
            {
                MaChiTietDv = $"DV-{Guid.NewGuid():N}",
                MaPhieuKhamCls = request.MaPhieuKhamCls,
                MaDichVu = request.MaDichVu,
                TrangThai = "da_lap",
                GhiChu = request.GhiChu
            };

            _db.ChiTietDichVus.Add(chiTiet);
            await _db.SaveChangesAsync();

            var loaded = await _db.ChiTietDichVus
                .AsNoTracking()
                .Include(c => c.DichVuYTe)
                .FirstAsync(c => c.MaChiTietDv == chiTiet.MaChiTietDv);

            return MapClsItem(loaded);
        }

        public async Task<IReadOnlyList<ClsItemDto>> LayDanhSachDichVuClsAsync(string maPhieuKhamCls)
        {
            var list = await _db.ChiTietDichVus
                .AsNoTracking()
                .Where(c => c.MaPhieuKhamCls == maPhieuKhamCls)
                .Include(c => c.DichVuYTe)
                .ToListAsync();

            return [.. list.Select(MapClsItem)];
        }

        // ================== 4. KẾT QUẢ CLS ==================

        public async Task<ClsResultDto> TaoKetQuaClsAsync(ClsResultCreateRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.MaChiTietDv))
                throw new ArgumentException("MaChiTietDv là bắt buộc");
            if (string.IsNullOrWhiteSpace(request.TrangThaiChot))
                throw new ArgumentException("TrangThaiChot là bắt buộc");
            if (string.IsNullOrWhiteSpace(request.MaNhanSuThucHien))
                throw new ArgumentException("MaNhanSuThucHien là bắt buộc");

            var chiTiet = await _db.ChiTietDichVus
                .Include(c => c.DichVuYTe)
                .FirstOrDefaultAsync(c => c.MaChiTietDv == request.MaChiTietDv)
                    ?? throw new InvalidOperationException("Không tìm thấy chi tiết dịch vụ");

            var ketQua = await _db.KetQuaDichVus
                .FirstOrDefaultAsync(k => k.MaChiTietDv == request.MaChiTietDv);

            var now = DateTime.Now;

            if (ketQua is null)
            {
                ketQua = new KetQuaDichVu
                {
                    MaKetQua = $"KQ-{Guid.NewGuid():N}",
                    MaChiTietDv = chiTiet.MaChiTietDv,
                    TrangThaiChot = request.TrangThaiChot,
                    NoiDungKetQua = request.NoiDungKetQua ?? "",
                    MaNguoiTao = request.MaNhanSuThucHien,
                    ThoiGianTao = now,
                    TepDinhKem = request.TepDinhKem
                };
                _db.KetQuaDichVus.Add(ketQua);
            }
            else
            {
                ketQua.TrangThaiChot = request.TrangThaiChot;
                ketQua.NoiDungKetQua = request.NoiDungKetQua ?? "";
                ketQua.MaNguoiTao = request.MaNhanSuThucHien;
                ketQua.TepDinhKem = request.TepDinhKem;
            }

            chiTiet.TrangThai = "da_hoan_tat";

            await _db.SaveChangesAsync();

            await _db.Entry(ketQua).Reference(k => k.NhanVienYTes).LoadAsync();

            var dto = new ClsResultDto
            {
                MaKetQua = ketQua.MaKetQua,
                MaChiTietDv = ketQua.MaChiTietDv,
                MaPhieuKhamCls = chiTiet.MaPhieuKhamCls,
                MaDichVu = chiTiet.MaDichVu,
                TenDichVu = chiTiet.DichVuYTe?.TenDichVu ?? "",
                TrangThaiChot = ketQua.TrangThaiChot,
                NoiDungKetQua = ketQua.NoiDungKetQua,
                MaNhanSuThucHien = ketQua.MaNguoiTao,
                TenNhanSuThucHien = ketQua.NhanVienYTes?.HoTen ?? "",
                ThoiGianTao = ketQua.ThoiGianTao,
                TepDinhKem = ketQua.TepDinhKem
            };

            // Realtime: có kết quả CLS mới
            await _realtime.BroadcastClsResultCreatedAsync(dto);

            return dto;
        }

        public async Task<IReadOnlyList<ClsResultDto>> LayKetQuaTheoPhieuClsAsync(string maPhieuKhamCls)
        {
            var list = await _db.KetQuaDichVus
                .AsNoTracking()
                .Include(k => k.NhanVienYTes)
                .Include(k => k.ChiTietDichVu)
                    .ThenInclude(ct => ct.DichVuYTe)
                .Where(k => k.ChiTietDichVu.MaPhieuKhamCls == maPhieuKhamCls)
                .ToListAsync();

            return [.. list.Select(k => new ClsResultDto
            {
                MaKetQua = k.MaKetQua,
                MaChiTietDv = k.MaChiTietDv,
                MaPhieuKhamCls = k.ChiTietDichVu.MaPhieuKhamCls,
                MaDichVu = k.ChiTietDichVu.MaDichVu,
                TenDichVu = k.ChiTietDichVu.DichVuYTe?.TenDichVu ?? "",
                TrangThaiChot = k.TrangThaiChot,
                NoiDungKetQua = k.NoiDungKetQua,
                MaNhanSuThucHien = k.MaNguoiTao,
                TenNhanSuThucHien = k.NhanVienYTes?.HoTen ?? "",
                ThoiGianTao = k.ThoiGianTao,
                TepDinhKem = k.TepDinhKem
            })];
        }

        // ================== 5. PHIẾU TỔNG HỢP KQ CLS ==================

        public async Task<ClsSummaryDto> TaoTongHopAsync(string maPhieuKhamCls)
        {
            if (string.IsNullOrWhiteSpace(maPhieuKhamCls))
                throw new ArgumentException("MaPhieuKhamCls là bắt buộc");

            var phieuCls = await _db.PhieuKhamCanLamSangs
                .Include(p => p.PhieuKhamLamSang)
                    .ThenInclude(ls => ls.BenhNhan)
                .FirstOrDefaultAsync(p => p.MaPhieuKhamCls == maPhieuKhamCls)
                    ?? throw new InvalidOperationException("Không tìm thấy phiếu CLS");

            var bn = phieuCls.PhieuKhamLamSang.BenhNhan;
            var clsResults = await LayKetQuaTheoPhieuClsAsync(maPhieuKhamCls);

            var snapshotObj = new
            {
                PhieuCls = new
                {
                    phieuCls.MaPhieuKhamCls,
                    phieuCls.MaPhieuKhamLs,
                    phieuCls.NgayGioLap,
                    phieuCls.TrangThai,
                    phieuCls.GhiChu
                },
                BenhNhan = new
                {
                    bn.MaBenhNhan,
                    bn.HoTen,
                    bn.NgaySinh,
                    bn.GioiTinh,
                    bn.DienThoai,
                    bn.DiaChi
                },
                KetQua = clsResults
            };

            var snapshotJson = JsonSerializer.Serialize(snapshotObj);
            var now = DateTime.Now;

            var summary = await _db.PhieuTongHopKetQuas
                .FirstOrDefaultAsync(s => s.MaPhieuKhamCls == maPhieuKhamCls);

            var isNew = summary is null;

            if (summary is null)
            {
                summary = new PhieuTongHopKetQua
                {
                    MaPhieuTongHop = $"THKQ-{Guid.NewGuid():N}",
                    MaPhieuKhamCls = maPhieuKhamCls,
                    LoaiPhieu = "tong_hop_cls",
                    TrangThai = "cho_xu_ly",
                    ThoiGianXuLy = now,
                    SnapshotJson = snapshotJson
                };
                _db.PhieuTongHopKetQuas.Add(summary);
            }
            else
            {
                summary.SnapshotJson = snapshotJson;
                summary.ThoiGianXuLy = now;
            }

            await _db.SaveChangesAsync();

            var dto = new ClsSummaryDto
            {
                MaPhieuTongHop = summary.MaPhieuTongHop,
                MaPhieuKhamCls = summary.MaPhieuKhamCls,
                MaBenhNhan = bn.MaBenhNhan,
                TenBenhNhan = bn.HoTen,
                NgayGioLapPhieuCls = phieuCls.NgayGioLap,
                ThoiGianXuLy = summary.ThoiGianXuLy,
                TrangThai = summary.TrangThai,
                SnapshotJson = summary.SnapshotJson
            };

            if (isNew)
            {
                await _realtime.BroadcastClsSummaryCreatedAsync(dto);
            }
            else
            {
                await _realtime.BroadcastClsSummaryUpdatedAsync(dto);
            }

            return dto;
        }

        public async Task<PagedResult<ClsSummaryDto>> LayTongHopKetQuaChoLapPhieuKhamAsync(ClsSummaryFilter filter)
        {
            if (string.IsNullOrWhiteSpace(filter.MaBenhNhan))
                throw new ArgumentException("MaBenhNhan là bắt buộc trong filter");

            var page = filter.Page <= 0 ? 1 : filter.Page;
            var pageSize = filter.PageSize <= 0 ? 20 : filter.PageSize;

            var query =
                from s in _db.PhieuTongHopKetQuas.AsNoTracking()
                join cls in _db.PhieuKhamCanLamSangs.AsNoTracking()
                    on s.MaPhieuKhamCls equals cls.MaPhieuKhamCls
                join ls in _db.PhieuKhamLamSangs.AsNoTracking()
                    on cls.MaPhieuKhamLs equals ls.MaPhieuKham
                join bn in _db.BenhNhans.AsNoTracking()
                    on ls.MaBenhNhan equals bn.MaBenhNhan
                where bn.MaBenhNhan == filter.MaBenhNhan
                select new { s, cls, ls, bn };

            if (filter.FromDate.HasValue)
            {
                var from = filter.FromDate.Value.Date;
                query = query.Where(x => x.s.ThoiGianXuLy >= from);
            }

            if (filter.ToDate.HasValue)
            {
                var to = filter.ToDate.Value.Date.AddDays(1);
                query = query.Where(x => x.s.ThoiGianXuLy < to);
            }

            if (!string.IsNullOrWhiteSpace(filter.TrangThai))
                query = query.Where(x => x.s.TrangThai == filter.TrangThai);

            query = query.OrderByDescending(x => x.s.ThoiGianXuLy);

            var totalItems = await query.CountAsync();
            var pageData = await query
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            var dtos = pageData.Select(x => new ClsSummaryDto
            {
                MaPhieuTongHop = x.s.MaPhieuTongHop,
                MaPhieuKhamCls = x.s.MaPhieuKhamCls,
                MaBenhNhan = x.bn.MaBenhNhan,
                TenBenhNhan = x.bn.HoTen,
                NgayGioLapPhieuCls = x.cls.NgayGioLap,
                ThoiGianXuLy = x.s.ThoiGianXuLy,
                TrangThai = x.s.TrangThai,
                SnapshotJson = x.s.SnapshotJson
            }).ToList();

            return new PagedResult<ClsSummaryDto>
            {
                Items = dtos,
                TotalItems = totalItems,
                Page = page,
                PageSize = pageSize
            };
        }

        public async Task<ClsSummaryDto?> LayPhieuTongHopKetQuaAsync(string maPhieuTongHop)
        {
            if (string.IsNullOrWhiteSpace(maPhieuTongHop))
                return null;

            var row =
                await (from s in _db.PhieuTongHopKetQuas.AsNoTracking()
                       join cls in _db.PhieuKhamCanLamSangs.AsNoTracking()
                            on s.MaPhieuKhamCls equals cls.MaPhieuKhamCls
                       join ls in _db.PhieuKhamLamSangs.AsNoTracking()
                            on cls.MaPhieuKhamLs equals ls.MaPhieuKham
                       join bn in _db.BenhNhans.AsNoTracking()
                            on ls.MaBenhNhan equals bn.MaBenhNhan
                       where s.MaPhieuTongHop == maPhieuTongHop
                       select new { s, cls, ls, bn })
                .FirstOrDefaultAsync();

            if (row is null) return null;

            return new ClsSummaryDto
            {
                MaPhieuTongHop = row.s.MaPhieuTongHop,
                MaPhieuKhamCls = row.s.MaPhieuKhamCls,
                MaBenhNhan = row.bn.MaBenhNhan,
                TenBenhNhan = row.bn.HoTen,
                NgayGioLapPhieuCls = row.cls.NgayGioLap,
                ThoiGianXuLy = row.s.ThoiGianXuLy,
                TrangThai = row.s.TrangThai,
                SnapshotJson = row.s.SnapshotJson
            };
        }

        public async Task<ClsSummaryDto?> CapNhatTrangThaiTongHopAsync(
            string maPhieuTongHop,
            ClsSummaryStatusUpdateRequest request)
        {
            if (string.IsNullOrWhiteSpace(maPhieuTongHop))
                return null;
            if (string.IsNullOrWhiteSpace(request.TrangThai))
                throw new ArgumentException("TrangThai là bắt buộc");

            var summary = await _db.PhieuTongHopKetQuas
                .FirstOrDefaultAsync(s => s.MaPhieuTongHop == maPhieuTongHop);

            if (summary is null) return null;

            summary.TrangThai = request.TrangThai;
            summary.ThoiGianXuLy = DateTime.Now;

            await _db.SaveChangesAsync();

            var dto = await LayPhieuTongHopKetQuaAsync(maPhieuTongHop);

            if (dto is not null)
            {
                await _realtime.BroadcastClsSummaryUpdatedAsync(dto);
            }

            return dto;
        }

        public async Task<ClsSummaryDto?> CapNhatPhieuTongHopAsync(
            string maPhieuTongHop,
            ClsSummaryUpdateRequest request)
        {
            if (string.IsNullOrWhiteSpace(maPhieuTongHop))
                return null;

            var summary = await _db.PhieuTongHopKetQuas
                .FirstOrDefaultAsync(s => s.MaPhieuTongHop == maPhieuTongHop);

            if (summary is null) return null;

            if (!string.IsNullOrWhiteSpace(request.TrangThai))
                summary.TrangThai = request.TrangThai;

            if (!string.IsNullOrWhiteSpace(request.MaNhanSuXuLy))
                summary.MaNhanSuXuLy = request.MaNhanSuXuLy; // FE là nguồn chuẩn

            if (request.SnapshotJson is not null)
                summary.SnapshotJson = request.SnapshotJson;

            summary.ThoiGianXuLy = request.ThoiGianXuLy ?? DateTime.Now;

            await _db.SaveChangesAsync();

            var dto = await LayPhieuTongHopKetQuaAsync(maPhieuTongHop);

            if (dto is not null)
            {
                await _realtime.BroadcastClsSummaryUpdatedAsync(dto);
            }

            return dto;
        }

    }
}
