﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HealthCare.Datas;
using HealthCare.DTOs;
using HealthCare.Entities;
using HealthCare.Realtime;
using Microsoft.EntityFrameworkCore;
using HealthCare.RenderID;
using HealthCare.Services;
namespace HealthCare.Services
{
    public class AppointmentService(DataContext db, IRealtimeService realtime, INotificationService notifications, IDashboardService dashboard) : IAppointmentService
    {
        private readonly DataContext _db = db;
        private readonly IRealtimeService _realtime = realtime;
        private readonly INotificationService _notifications = notifications;
       private readonly IDashboardService _dashboard = dashboard;
        // ========= TÌM KIẾM / PHÂN TRANG LỊCH HẸN =========
        public async Task<PagedResult<AppointmentReadRequestDto>> TimKiemLichHenAsync(
            AppointmentFilterRequest filter)
        {
            await DeactivateOldAppointmentsAsync();

            var query = _db.LichHenKhams
                .AsNoTracking()
                .Include(l => l.LichTruc)
                    .ThenInclude(lt => lt.Phong)
                        .ThenInclude(p => p.KhoaChuyenMon)
                .Include(l => l.LichTruc)
                    .ThenInclude(lt => lt.Phong)
                        .ThenInclude(p => p.BacSiPhuTrach)
                .Where(l => l.CoHieuLuc); // chỉ lấy lịch hiệu lực

            if (filter.FromDate.HasValue)
            {
                var from = filter.FromDate.Value.Date;
                query = query.Where(l => l.NgayHen >= from);
            }

            if (filter.ToDate.HasValue)
            {
                var toExclusive = filter.ToDate.Value.Date.AddDays(1);
                query = query.Where(l => l.NgayHen < toExclusive);
            }

            if (!string.IsNullOrWhiteSpace(filter.MaBenhNhan))
            {
                query = query.Where(l => l.MaBenhNhan == filter.MaBenhNhan);
            }

            if (!string.IsNullOrWhiteSpace(filter.LoaiHen))
            {
                query = query.Where(l => l.LoaiHen == filter.LoaiHen);
            }

            if (!string.IsNullOrWhiteSpace(filter.TrangThai))
            {
                query = query.Where(l => l.TrangThai == filter.TrangThai);
            }

            var page = filter.Page <= 0 ? 1 : filter.Page;
            var pageSize = filter.PageSize <= 0 ? 50 : filter.PageSize;

            var totalItems = await query.CountAsync();

            var list = await query
                .OrderBy(l => l.NgayHen)
                .ThenBy(l => l.GioHen)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            var items = list.Select(MapToDto).ToList();

            return new PagedResult<AppointmentReadRequestDto>
            {
                Items = items,
                TotalItems = totalItems,
                Page = page,
                PageSize = pageSize
            };
        }

        // ========= TẠO LỊCH HẸN =========
        public async Task<AppointmentReadRequestDto> TaoLichHenAsync(
      AppointmentCreateRequestDto request)
        {
            if (string.IsNullOrWhiteSpace(request.TenBenhNhan))
                throw new ArgumentException("TenBenhNhan là bắt buộc");

            if (string.IsNullOrWhiteSpace(request.SoDienThoai))
                throw new ArgumentException("SoDienThoai là bắt buộc");

            if (request.NgayHen == default)
                throw new ArgumentException("NgayHen là bắt buộc");

            if (request.GioHen == default)
                throw new ArgumentException("GioHen là bắt buộc");

            if (string.IsNullOrWhiteSpace(request.TenBacSiKham))
                throw new ArgumentException("TenBacSiKham là bắt buộc");

            if (string.IsNullOrWhiteSpace(request.KhoaKham))
                throw new ArgumentException("KhoaKham là bắt buộc");

            var date = request.NgayHen.Date;
            var gio = request.GioHen;

            // 1. Tìm bác sĩ theo tên + khoa
            var bacSi = await _db.NhanVienYTes
                .AsNoTracking()
                .FirstOrDefaultAsync(nv =>
                    nv.VaiTro == "bac_si"
                    && nv.HoTen == request.TenBacSiKham
                    && nv.KhoaChuyenMon.TenKhoa == request.KhoaKham); // giả định KhoaKham = MaKhoa

            if (bacSi is null)
                throw new ArgumentException("Không tìm thấy bác sĩ phù hợp với TenBacSiKham và KhoaKham");

            // 2. Tìm phòng mà bác sĩ phụ trách
            var phongIds = await _db.Phongs
                .AsNoTracking()
                .Where(p => p.MaBacSiPhuTrach == bacSi.MaNhanVien)
                .Select(p => p.MaPhong)
                .ToListAsync();

            if (phongIds.Count == 0)
                throw new ArgumentException("Bác sĩ không có phòng phụ trách phù hợp");

            // 3. Tìm lịch trực của phòng trong ngày + khung giờ
            var lichTruc = await _db.LichTrucs
                .AsNoTracking()
                .Where(lt => phongIds.Contains(lt.MaPhong)
                             && lt.Ngay.Date == date
                             && !lt.NghiTruc
                             && lt.GioBatDau <= gio
                             && lt.GioKetThuc > gio)
                .OrderBy(lt => lt.GioBatDau)
                .FirstOrDefaultAsync();

            if (lichTruc is null)
                throw new InvalidOperationException("Không tìm thấy lịch trực phù hợp với ngày/giờ và bác sĩ đã chọn");

            // 4. Sinh mã lịch hẹn
            var maLichHen = GeneratorID.NewLichHenId();

            var entity = new LichHenKham
            {
                MaLichHen = maLichHen,
                CoHieuLuc = true,
                NgayHen = date,
                GioHen = gio,
                ThoiLuongPhut = 30,
                MaBenhNhan = request.MaBenhNhan,
                LoaiHen = request.LoaiHen,
                TenBenhNhan = request.TenBenhNhan,
                SoDienThoai = request.SoDienThoai,
                MaLichTruc = lichTruc.MaLichTruc,
                GhiChu = request.GhiChu,
                TrangThai = string.IsNullOrWhiteSpace(request.TrangThai)
                    ? "dang_cho"
                    : request.TrangThai
            };

            _db.LichHenKhams.Add(entity);
            await _db.SaveChangesAsync();

            // 5. Reload đầy đủ nav để map ra DTO (TenBacSiKham, KhoaKham...)
            var saved = await _db.LichHenKhams
                .Include(l => l.LichTruc)
                    .ThenInclude(lt => lt.Phong)
                        .ThenInclude(p => p.KhoaChuyenMon)
                .Include(l => l.LichTruc)
                    .ThenInclude(lt => lt.Phong)
                        .ThenInclude(p => p.BacSiPhuTrach)
                .AsNoTracking()
                .FirstAsync(l => l.MaLichHen == entity.MaLichHen);

            var dto = MapToDto(saved);

            await _realtime.BroadcastAppointmentChangedAsync(dto);
            await TaoThongBaoLichHenChoBacSiAsync(dto, "created");
            var dashboard = await _dashboard.LayDashboardHomNayAsync();
            await _realtime.BroadcastTodayAppointmentsKpiAsync(dashboard.LichHenHomNay);
            await _realtime.BroadcastUpcomingAppointmentsAsync(dashboard.LichHenSapToi);
            await _realtime.BroadcastRecentActivitiesAsync(dashboard.HoatDongGanDay);
            return dto;
        }


        // ========= LẤY CHI TIẾT LỊCH HẸN =========
        public async Task<AppointmentReadRequestDto> LayLichHenAsync(string maLichHen)
        {
            var entity = await _db.LichHenKhams
                .Include(l => l.LichTruc)
                    .ThenInclude(lt => lt.Phong)
                        .ThenInclude(p => p.KhoaChuyenMon)
                .Include(l => l.LichTruc)
                    .ThenInclude(lt => lt.Phong)
                        .ThenInclude(p => p.BacSiPhuTrach)
                .AsNoTracking()
                .FirstOrDefaultAsync(l => l.MaLichHen == maLichHen);

            if (entity is null)
                throw new KeyNotFoundException($"Không tìm thấy lịch hẹn {maLichHen}");

            return MapToDto(entity);
        }

        // ========= CẬP NHẬT TRẠNG THÁI LỊCH HẸN =========
        public async Task<AppointmentReadRequestDto?> CapNhatTrangThaiLichHenAsync(
            string maLichHen,
            AppointmentStatusUpdateRequest request)
        {
            var entity = await _db.LichHenKhams
                .Include(l => l.LichTruc)
                    .ThenInclude(lt => lt.Phong)
                        .ThenInclude(p => p.KhoaChuyenMon)
                .Include(l => l.LichTruc)
                    .ThenInclude(lt => lt.Phong)
                        .ThenInclude(p => p.BacSiPhuTrach)
                .FirstOrDefaultAsync(l => l.MaLichHen == maLichHen);

            if (entity is null)
                return null;

            entity.TrangThai = request.TrangThai;

         

            await _db.SaveChangesAsync();

            var dto = MapToDto(entity);
            await _realtime.BroadcastAppointmentChangedAsync(dto);
            await TaoThongBaoLichHenChoBacSiAsync(dto, "status_changed");
            var dashboard = await _dashboard.LayDashboardHomNayAsync();
            await _realtime.BroadcastTodayAppointmentsKpiAsync(dashboard.LichHenHomNay);
            await _realtime.BroadcastUpcomingAppointmentsAsync(dashboard.LichHenSapToi);
            await _realtime.BroadcastRecentActivitiesAsync(dashboard.HoatDongGanDay);
            return dto;
        }

        // ========= CẬP NHẬT THÔNG TIN LỊCH HẸN =========
        public async Task<AppointmentReadRequestDto?> CapNhatLichHenAsync(
            string maLichHen,
            AppointmentUpdateRequest request)
        {
            var entity = await _db.LichHenKhams
                .Include(l => l.LichTruc)
                    .ThenInclude(lt => lt.Phong)
                        .ThenInclude(p => p.KhoaChuyenMon)
                .Include(l => l.LichTruc)
                    .ThenInclude(lt => lt.Phong)
                        .ThenInclude(p => p.BacSiPhuTrach)
                .FirstOrDefaultAsync(l => l.MaLichHen == maLichHen);

            if (entity is null)
                return null;

            if (request.NgayHen.HasValue)
            {
                entity.NgayHen = request.NgayHen.Value.Date;
            }

            if (request.GioHen.HasValue)
            {
                entity.GioHen = request.GioHen.Value;
            }

            if (!string.IsNullOrWhiteSpace(request.GhiChu))
            {
                entity.GhiChu = request.GhiChu;
            }

            await _db.SaveChangesAsync();

            var dto = MapToDto(entity);
            await _realtime.BroadcastAppointmentChangedAsync(dto);
            await TaoThongBaoLichHenChoBacSiAsync(dto, "updated");
            var dashboard = await _dashboard.LayDashboardHomNayAsync();
            await _realtime.BroadcastTodayAppointmentsKpiAsync(dashboard.LichHenHomNay);
            await _realtime.BroadcastUpcomingAppointmentsAsync(dashboard.LichHenSapToi);
            await _realtime.BroadcastRecentActivitiesAsync(dashboard.HoatDongGanDay);
            return dto;
        }

        // ========= MAP ENTITY -> DTO =========
        private static AppointmentReadRequestDto MapToDto(LichHenKham l)
        {
            var phong = l.LichTruc?.Phong;
            var khoa = phong?.KhoaChuyenMon;
            var bacSi = phong?.BacSiPhuTrach;

            return new AppointmentReadRequestDto
            {
                MaLichHen = l.MaLichHen,
                NgayHen = l.NgayHen,
                GioHen = l.GioHen,
                MaBenhNhan = l.MaBenhNhan,
                LoaiHen = l.LoaiHen,
                TenBenhNhan = l.TenBenhNhan,
                SoDienThoai = l.SoDienThoai,
                MaBacSiKham = bacSi?.MaNhanVien ?? string.Empty,
                TenBacSiKham = bacSi?.HoTen ?? string.Empty,
                KhoaKham = khoa?.TenKhoa ?? string.Empty,
                MaLichTruc = l.MaLichTruc,
                GhiChu = l.GhiChu,
                TrangThai = l.TrangThai
            };
        }
        private async Task DeactivateOldAppointmentsAsync()
        {
            var today = DateTime.Today;
            var now = DateTime.Now.TimeOfDay;
            await _db.LichHenKhams
                .Where(l => l.CoHieuLuc && l.NgayHen < today )
                .ExecuteUpdateAsync(setters => setters
                    .SetProperty(l => l.CoHieuLuc, false)
                );
            await _db.LichHenKhams
               .Where(l => l.CoHieuLuc && l.GioHen < now)
               .ExecuteUpdateAsync(setters => setters
                   .SetProperty(l => l.TrangThai, "da_huy")
               );

        }
        private async Task TaoThongBaoLichHenChoBacSiAsync(
    AppointmentReadRequestDto lichHen,
    string action // "created" | "status_changed" | "updated"
)
        {
            if (lichHen == null) return;
            if (string.IsNullOrWhiteSpace(lichHen.MaBacSiKham)) return;

            // Build tiêu đề + nội dung theo loại hành động
            string title;
            string body;
            var trangThaiText = lichHen.TrangThai.ToString() switch
            {
                "dang_cho" => "Đang chờ",
                "da_xac_nhan" => "Đã xác nhận",
                _ => ""
            };

     
            switch (action)
            {
                case "created":
                    title = "Lịch hẹn mới";
                    body =
                        $"Bạn có lịch hẹn mới với bệnh nhân {lichHen.TenBenhNhan} " +
                        $"vào {lichHen.NgayHen:dd/MM/yyyy} lúc {lichHen.GioHen:hh\\:mm}.";
                    break;

                case "status_changed":
                    title = "Lịch hẹn cập nhật trạng thái";
                    body =
                        $"Lịch hẹn với bệnh nhân {lichHen.TenBenhNhan} " +
                        $"vào {lichHen.NgayHen:dd/MM/yyyy} {lichHen.GioHen:hh\\:mm} " +
                       $"đã được cập nhật trạng thái: {trangThaiText}.";
                    break;

                default:
                    title = "Lịch hẹn được cập nhật";
                    body =
                        $"Lịch hẹn với bệnh nhân {lichHen.TenBenhNhan} " +
                        $"vào {lichHen.NgayHen:dd/MM/yyyy} {lichHen.GioHen:hh\\:mm} đã được chỉnh sửa.";
                    break;
            }

            // Build request dùng đúng cấu trúc NotificationService đang xử lý
            var request = new NotificationCreateRequest
            {
                LoaiThongBao = "lich_hen",
                TieuDe = title,
                NoiDung = body,
                MucDoUuTien = "normal",

                // Map sang NguonLienQuan + MaDoiTuongLienQuan nếu anh muốn
                NguonLienQuan = "lich_hen",
                MaDoiTuongLienQuan = lichHen.MaLichHen,

                // 1 người nhận: bác sĩ (nhân viên y tế)
                NguoiNhan = new List<NotificationRecipientCreateRequest>
        {
            new NotificationRecipientCreateRequest
            {
                LoaiNguoiNhan = "nhan_vien_y_te",
                MaNguoiNhan = lichHen.MaBacSiKham
            }
        }
            };

            // Ghi vào DB qua NotificationService
            await _notifications.TaoThongBaoAsync(request);
        }
    }
}
