﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HealthCare.DTOs;
using HealthCare.Hubs;
using Microsoft.AspNetCore.SignalR;

namespace HealthCare.Realtime
{
    /// <summary>
    /// Facade dùng từ các service nghiệp vụ để bắn realtime (SignalR).
    /// Quy ước group:
    ///  - "staff"  : toàn bộ nhân sự (bác sĩ + y tá) – FE nên JoinRoleAsync("staff")
    ///  - "bac_si" : tất cả tài khoản bác sĩ – FE nên JoinRoleAsync("bac_si") nếu user là bác sĩ
    ///  - "y_ta"   : tất cả tài khoản y tá – FE nên JoinRoleAsync("y_ta") nếu user là y tá
    ///
    /// Ngoài ra vẫn có group theo user / phòng:
    ///  - RealtimeHub.GetUserGroupName(loaiNguoiDung, maNguoiDung)
    ///  - RealtimeHub.GetRoomGroupName(maPhong)
    /// </summary>
    public class RealtimeService(IHubContext<RealtimeHub, IRealtimeClient> hub) : IRealtimeService
    {
        private readonly IHubContext<RealtimeHub, IRealtimeClient> _hub = hub;

        // Nhân sự chung (bác sĩ + y tá)
        private static readonly string StaffGroupName =
            RealtimeHub.GetRoleGroupName("staff");

        // Tất cả bác sĩ
        private static readonly string DoctorRoleGroupName =
            RealtimeHub.GetRoleGroupName("bac_si");

        // Tất cả y tá
        private static readonly string NurseRoleGroupName =
            RealtimeHub.GetRoleGroupName("y_ta");

        // ==============================
        // ===== DASHBOARD / KPI ========
        // ==============================

        // Tất cả nhân sự (bác sĩ + y tá) xem dashboard
        public Task BroadcastDashboardTodayAsync(DashboardTodayDto dashboard)
        {
            var tasks = new List<Task>
            {
                _hub.Clients.Group(StaffGroupName).DashboardTodayUpdated(dashboard),
                _hub.Clients.Group(DoctorRoleGroupName).DashboardTodayUpdated(dashboard),
                _hub.Clients.Group(NurseRoleGroupName).DashboardTodayUpdated(dashboard)
            };
            return Task.WhenAll(tasks);

        }

        public Task BroadcastTodayPatientsKpiAsync(TodayPatientsKpiDto dto)
        {
            var tasks = new List<Task>
            {
                _hub.Clients.Group(StaffGroupName).TodayPatientsKpiUpdated(dto),
                _hub.Clients.Group(DoctorRoleGroupName).TodayPatientsKpiUpdated(dto),
                _hub.Clients.Group(NurseRoleGroupName).TodayPatientsKpiUpdated(dto)
            };
            return Task.WhenAll(tasks);
        }

        public Task BroadcastTodayAppointmentsKpiAsync(TodayAppointmentsKpiDto dto)
        {
            var tasks = new List<Task>
            {
                _hub.Clients.Group(StaffGroupName).TodayAppointmentsKpiUpdated(dto),
                _hub.Clients.Group(DoctorRoleGroupName).TodayAppointmentsKpiUpdated(dto),
                _hub.Clients.Group(NurseRoleGroupName).TodayAppointmentsKpiUpdated(dto)
            };
            return Task.WhenAll(tasks);
        }

        public Task BroadcastTodayRevenueKpiAsync(TodayRevenueKpiDto dto)
        {
            var tasks = new List<Task>
            {
                _hub.Clients.Group(StaffGroupName).TodayRevenueKpiUpdated(dto),
                _hub.Clients.Group(DoctorRoleGroupName).TodayRevenueKpiUpdated(dto),
                _hub.Clients.Group(NurseRoleGroupName).TodayRevenueKpiUpdated(dto)
            };
            return Task.WhenAll(tasks);
        }

        public Task BroadcastTodayExamOverviewAsync(TodayExamOverviewDto dto)
        {
            var tasks = new List<Task>
            {
                _hub.Clients.Group(StaffGroupName).TodayExamOverviewUpdated(dto),
                _hub.Clients.Group(DoctorRoleGroupName).TodayExamOverviewUpdated(dto),
                _hub.Clients.Group(NurseRoleGroupName).TodayExamOverviewUpdated(dto)
            };
            return Task.WhenAll(tasks);
        }

        public Task BroadcastUpcomingAppointmentsAsync(
            IReadOnlyList<UpcomingAppointmentDashboardItemDto> items)
        {
            var tasks = new List<Task>
            {
                _hub.Clients.Group(StaffGroupName).UpcomingAppointmentsUpdated(items),
                _hub.Clients.Group(DoctorRoleGroupName).UpcomingAppointmentsUpdated(items),
                _hub.Clients.Group(NurseRoleGroupName).UpcomingAppointmentsUpdated(items)
            };
            return Task.WhenAll(tasks);
        }

        public Task BroadcastRecentActivitiesAsync(
            IReadOnlyList<DashboardActivityDto> items)
        {
            var tasks = new List<Task>
            {
                _hub.Clients.Group(StaffGroupName).RecentActivitiesUpdated(items),
                _hub.Clients.Group(DoctorRoleGroupName).RecentActivitiesUpdated(items),
                _hub.Clients.Group(NurseRoleGroupName).RecentActivitiesUpdated(items)
            };
            return Task.WhenAll(tasks);
        }


        // ==========================
        // ===== BỆNH NHÂN =========
        // ==========================

        public Task BroadcastPatientCreatedAsync(PatientDto benhNhan)
        {
            var tasks = new List<Task>
            {
                _hub.Clients.Group(StaffGroupName).PatientCreated(benhNhan),
                _hub.Clients.Group(DoctorRoleGroupName).PatientCreated(benhNhan),
                _hub.Clients.Group(NurseRoleGroupName).PatientCreated(benhNhan)
            };
            return Task.WhenAll(tasks);
        }

        public Task BroadcastPatientUpdatedAsync(PatientDto benhNhan)
        {
            var tasks = new List<Task>
            {
                _hub.Clients.Group(StaffGroupName).PatientUpdated(benhNhan),
                _hub.Clients.Group(DoctorRoleGroupName).PatientUpdated(benhNhan),
                _hub.Clients.Group(NurseRoleGroupName).PatientUpdated(benhNhan)
            };
            return Task.WhenAll(tasks);
        }

        public Task BroadcastPatientStatusUpdatedAsync(PatientDto benhNhan)
        {
            var tasks = new List<Task>
            {
                _hub.Clients.Group(StaffGroupName).PatientStatusUpdated(benhNhan),
                _hub.Clients.Group(DoctorRoleGroupName).PatientStatusUpdated(benhNhan),
                _hub.Clients.Group(NurseRoleGroupName).PatientStatusUpdated(benhNhan)
            };
            return Task.WhenAll(tasks);
        }


        // =====================================
        // ===== KHÁM BỆNH (LÂM SÀNG) =========
        // =====================================

        public Task BroadcastClinicalExamCreatedAsync(ClinicalExamDto phieuKham)
        {
            var tasks = new List<Task>
            {
                _hub.Clients.Group(StaffGroupName).ClinicalExamCreated(phieuKham),
                _hub.Clients.Group(DoctorRoleGroupName).ClinicalExamCreated(phieuKham),
                _hub.Clients.Group(NurseRoleGroupName).ClinicalExamCreated(phieuKham)
            };

            if (!string.IsNullOrWhiteSpace(phieuKham.MaPhong))
            {
                var roomGroup = RealtimeHub.GetRoomGroupName(phieuKham.MaPhong);
                tasks.Add(_hub.Clients.Group(roomGroup).ClinicalExamCreated(phieuKham));
            }

            return Task.WhenAll(tasks);
        }

        public Task BroadcastClinicalExamUpdatedAsync(ClinicalExamDto phieuKham)
        {
            var tasks = new List<Task>
            {
                _hub.Clients.Group(StaffGroupName).ClinicalExamUpdated(phieuKham),
                _hub.Clients.Group(DoctorRoleGroupName).ClinicalExamUpdated(phieuKham),
                _hub.Clients.Group(NurseRoleGroupName).ClinicalExamUpdated(phieuKham)
            };

            if (!string.IsNullOrWhiteSpace(phieuKham.MaPhong))
            {
                var roomGroup = RealtimeHub.GetRoomGroupName(phieuKham.MaPhong);
                tasks.Add(_hub.Clients.Group(roomGroup).ClinicalExamUpdated(phieuKham));
            }

            return Task.WhenAll(tasks);
        }

        public Task BroadcastFinalDiagnosisChangedAsync(FinalDiagnosisDto chanDoan)
        {
            var tasks = new List<Task>
            {
                _hub.Clients.Group(StaffGroupName).FinalDiagnosisChanged(chanDoan),
                _hub.Clients.Group(DoctorRoleGroupName).FinalDiagnosisChanged(chanDoan),
                _hub.Clients.Group(NurseRoleGroupName).FinalDiagnosisChanged(chanDoan)
            };
            return Task.WhenAll(tasks);
        }


        // ======================================
        // ===== CẬN LÂM SÀNG (CLS SERVICE) =====
        // ======================================

        public Task BroadcastClsOrderCreatedAsync(ClsOrderDto phieuCls)
        {
            var tasks = new List<Task>
            {
                _hub.Clients.Group(StaffGroupName).ClsOrderCreated(phieuCls),
                _hub.Clients.Group(DoctorRoleGroupName).ClsOrderCreated(phieuCls),
                _hub.Clients.Group(NurseRoleGroupName).ClsOrderCreated(phieuCls)
            };

            if (!string.IsNullOrWhiteSpace(phieuCls.MaPhong))
            {
                var roomGroup = RealtimeHub.GetRoomGroupName(phieuCls.MaPhong);
                tasks.Add(_hub.Clients.Group(roomGroup).ClsOrderCreated(phieuCls));
            }

            return Task.WhenAll(tasks);
        }

        public Task BroadcastClsOrderUpdatedAsync(ClsOrderDto phieuCls)
        {
            var tasks = new List<Task>
            {
                _hub.Clients.Group(StaffGroupName).ClsOrderUpdated(phieuCls),
                _hub.Clients.Group(DoctorRoleGroupName).ClsOrderUpdated(phieuCls),
                _hub.Clients.Group(NurseRoleGroupName).ClsOrderUpdated(phieuCls)
            };

            if (!string.IsNullOrWhiteSpace(phieuCls.MaPhong))
            {
                var roomGroup = RealtimeHub.GetRoomGroupName(phieuCls.MaPhong);
                tasks.Add(_hub.Clients.Group(roomGroup).ClsOrderUpdated(phieuCls));
            }

            return Task.WhenAll(tasks);
        }

        public Task BroadcastClsOrderStatusUpdatedAsync(ClsOrderDto phieuCls)
        {
            var tasks = new List<Task>
            {
                _hub.Clients.Group(StaffGroupName).ClsOrderStatusUpdated(phieuCls),
                _hub.Clients.Group(DoctorRoleGroupName).ClsOrderStatusUpdated(phieuCls),
                _hub.Clients.Group(NurseRoleGroupName).ClsOrderStatusUpdated(phieuCls)
            };

            if (!string.IsNullOrWhiteSpace(phieuCls.MaPhong))
            {
                var roomGroup = RealtimeHub.GetRoomGroupName(phieuCls.MaPhong);
                tasks.Add(_hub.Clients.Group(roomGroup).ClsOrderStatusUpdated(phieuCls));
            }

            return Task.WhenAll(tasks);
        }

        public Task BroadcastClsResultCreatedAsync(ClsResultDto ketQua)
        {
            var tasks = new List<Task>
            {
                _hub.Clients.Group(StaffGroupName).ClsResultCreated(ketQua),
                _hub.Clients.Group(DoctorRoleGroupName).ClsResultCreated(ketQua),
                _hub.Clients.Group(NurseRoleGroupName).ClsResultCreated(ketQua)
            };
            return Task.WhenAll(tasks);
        }

        public Task BroadcastClsSummaryCreatedAsync(ClsSummaryDto tongHop)
        {
            var tasks = new List<Task>
            {
                _hub.Clients.Group(StaffGroupName).ClsSummaryCreated(tongHop),
                _hub.Clients.Group(DoctorRoleGroupName).ClsSummaryCreated(tongHop),
                _hub.Clients.Group(NurseRoleGroupName).ClsSummaryCreated(tongHop)
            };
            return Task.WhenAll(tasks);
        }

        public Task BroadcastClsSummaryUpdatedAsync(ClsSummaryDto tongHop)
        {
            var tasks = new List<Task>
            {
                _hub.Clients.Group(StaffGroupName).ClsSummaryUpdated(tongHop),
                _hub.Clients.Group(DoctorRoleGroupName).ClsSummaryUpdated(tongHop),
                _hub.Clients.Group(NurseRoleGroupName).ClsSummaryUpdated(tongHop)
            };
            return Task.WhenAll(tasks);
        }


        // =====================================
        // ===== LƯỢT KHÁM (VISIT / HISTORY) ===
        // =====================================

        public Task BroadcastVisitCreatedAsync(HistoryVisitRecordDto luotKham)
        {
            var tasks = new List<Task>
            {
                _hub.Clients.Group(StaffGroupName).VisitCreated(luotKham),
                _hub.Clients.Group(DoctorRoleGroupName).VisitCreated(luotKham),
                _hub.Clients.Group(NurseRoleGroupName).VisitCreated(luotKham)
            };
            return Task.WhenAll(tasks);
        }

        public Task BroadcastVisitStatusUpdatedAsync(HistoryVisitRecordDto luotKham)
        {
            var tasks = new List<Task>
            {
                _hub.Clients.Group(StaffGroupName).VisitStatusUpdated(luotKham),
                _hub.Clients.Group(DoctorRoleGroupName).VisitStatusUpdated(luotKham),
                _hub.Clients.Group(NurseRoleGroupName).VisitStatusUpdated(luotKham)
            };
            return Task.WhenAll(tasks);
        }


        // ==========================
        // ===== HÀNG ĐỢI (QUEUE) ===
        // ==========================

        // Hàng đợi gửi theo phòng, FE join group theo phòng.
        public Task BroadcastQueueByRoomAsync(
            string maPhong,
            IReadOnlyList<QueueItemDto> items)
        {
            var groupName = RealtimeHub.GetRoomGroupName(maPhong);
            return _hub.Clients.Group(groupName).QueueByRoomUpdated(items);
        }

        public Task BroadcastQueueItemChangedAsync(QueueItemDto item)
        {
            if (string.IsNullOrWhiteSpace(item.MaPhong))
                return Task.CompletedTask;

            var groupName = RealtimeHub.GetRoomGroupName(item.MaPhong);
            return _hub.Clients.Group(groupName).QueueItemChanged(item);
        }


        // ==========================
        // ===== LỊCH HẸN ==========
        // ==========================

        public Task BroadcastAppointmentChangedAsync(
            AppointmentReadRequestDto lichHen)
        {
            var tasks = new List<Task>
            {
                // Dashboard + màn Lịch hẹn cho toàn bộ nhân sự
                _hub.Clients.Group(StaffGroupName).AppointmentChanged(lichHen),
                _hub.Clients.Group(DoctorRoleGroupName).AppointmentChanged(lichHen),
                _hub.Clients.Group(NurseRoleGroupName).AppointmentChanged(lichHen)
            };

            // Gửi thêm cho đúng bác sĩ nếu DTO có MaBacSiKham
            if (!string.IsNullOrWhiteSpace(lichHen.MaBacSiKham))
            {
                var doctorUserGroup =
                    RealtimeHub.GetUserGroupName("bac_si", lichHen.MaBacSiKham);
                tasks.Add(_hub.Clients.Group(doctorUserGroup).AppointmentChanged(lichHen));
            }

            return Task.WhenAll(tasks);
        }


        // ===================================
        // ===== HOÁ ĐƠN / THANH TOÁN =======
        // ===================================

        public Task BroadcastInvoiceChangedAsync(InvoiceDto hoaDon)
        {
            var tasks = new List<Task>
            {
                _hub.Clients.Group(StaffGroupName).InvoiceChanged(hoaDon),
                _hub.Clients.Group(DoctorRoleGroupName).InvoiceChanged(hoaDon),
                _hub.Clients.Group(NurseRoleGroupName).InvoiceChanged(hoaDon)
            };
            return Task.WhenAll(tasks);
        }


        // ==========================
        // ===== THÔNG BÁO =========
        // ==========================

        public Task BroadcastNotificationCreatedAsync(NotificationDto thongBao)
        {
            var loai = (thongBao.LoaiNguoiNhan ?? string.Empty).Trim().ToLowerInvariant();
            var ma = (thongBao.MaNguoiNhan ?? string.Empty).Trim();

            // Không chỉ đích danh → broadcast theo role
            if (string.IsNullOrWhiteSpace(ma))
            {
                // Không chỉ rõ loại → gửi cho toàn bộ nhân sự
                if (string.IsNullOrWhiteSpace(loai) ||
                    loai is "nhan_su" or "staff" or "nhan_vien_y_te")
                {
                    return _hub.Clients.Group(StaffGroupName).NotificationCreated(thongBao);
                }

                if (loai == "bac_si")
                {
                    return _hub.Clients.Group(DoctorRoleGroupName).NotificationCreated(thongBao);
                }

                if (loai == "y_ta")
                {
                    return _hub.Clients.Group(NurseRoleGroupName).NotificationCreated(thongBao);
                }

                // Loại khác không rõ → fallback nhân sự chung
                return _hub.Clients.Group(StaffGroupName).NotificationCreated(thongBao);
            }

            // Có mã người nhận → gửi theo user group (bac_si / y_ta)
            var userGroup = RealtimeHub.GetUserGroupName(thongBao.LoaiNguoiNhan, thongBao.MaNguoiNhan);
            return _hub.Clients.Group(userGroup).NotificationCreated(thongBao);
        }

        public Task BroadcastNotificationUpdatedAsync(NotificationDto thongBao)
        {
            var loai = (thongBao.LoaiNguoiNhan ?? string.Empty).Trim().ToLowerInvariant();
            var ma = (thongBao.MaNguoiNhan ?? string.Empty).Trim();

            if (string.IsNullOrWhiteSpace(ma))
            {
                if (string.IsNullOrWhiteSpace(loai) ||
                    loai is "nhan_su" or "staff" or "nhan_vien_y_te")
                {
                    return _hub.Clients.Group(StaffGroupName).NotificationUpdated(thongBao);
                }

                if (loai == "bac_si")
                {
                    return _hub.Clients.Group(DoctorRoleGroupName).NotificationUpdated(thongBao);
                }

                if (loai == "y_ta")
                {
                    return _hub.Clients.Group(NurseRoleGroupName).NotificationUpdated(thongBao);
                }

                return _hub.Clients.Group(StaffGroupName).NotificationUpdated(thongBao);
            }

            var userGroup = RealtimeHub.GetUserGroupName(thongBao.LoaiNguoiNhan, thongBao.MaNguoiNhan);
            return _hub.Clients.Group(userGroup).NotificationUpdated(thongBao);
        }
    }
}
