﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HealthCare.Datas;
using HealthCare.DTOs;
using HealthCare.Entities;
using HealthCare.Realtime;
using Microsoft.EntityFrameworkCore;

namespace HealthCare.Services
{
    /// <summary>
    /// Service quản lý phiếu khám lâm sàng + chẩn đoán cuối.
    /// </summary>
    public class ClinicalService(
    DataContext db,
    IRealtimeService realtime,
    IDashboardService dashboard,
    INotificationService notifications, IQueueService queue) : IClinicalService
    {
        private readonly DataContext _db = db;
        private readonly IRealtimeService _realtime = realtime;
        private readonly IDashboardService _dashboard = dashboard;
        private readonly INotificationService _notifications = notifications;
        private readonly IQueueService _queue = queue;
        // ================== HELPER ==================

        private static string? BuildThongTinChiTiet(BenhNhan bn)
        {
            var parts = new List<string>();

            void Add(string label, string? value)
            {
                if (!string.IsNullOrWhiteSpace(value))
                    parts.Add($"{label}: {value}");
            }

            Add("Dị ứng", bn.DiUng);
            Add("Chống chỉ định", bn.ChongChiDinh);
            Add("Thuốc đang dùng", bn.ThuocDangDung);
            Add("Tiền sử bệnh", bn.TieuSuBenh);
            Add("Tiền sử phẫu thuật", bn.TienSuPhauThuat);
            Add("Nhóm máu", bn.NhomMau);
            Add("Bệnh mạn tính", bn.BenhManTinh);
            Add("Sinh hiệu", bn.SinhHieu);

            return parts.Count == 0 ? null : string.Join(" | ", parts);
        }

        private static ClinicalExamDto MapClinicalExam(PhieuKhamLamSang phieu)
        {
            var bn = phieu.BenhNhan;
            var dv = phieu.DichVuKham;
            var lichHen = phieu.LichHenKham;

            return new ClinicalExamDto
            {
                MaPhieuKham = phieu.MaPhieuKham,
                MaBenhNhan = phieu.MaBenhNhan,
                HoTen = bn.HoTen,
                NgaySinh = bn.NgaySinh,
                GioiTinh = bn.GioiTinh,
                DienThoai = bn.DienThoai,
                Email = bn.Email,
                DiaChi = bn.DiaChi,

                // Khoa/phòng: hiện BE chưa join sang Phong/Khoa, FE có thể lấy qua queue
                MaKhoa = "",
                TenKhoa = null,
                MaPhong = dv?.MaPhongThucHien ?? "",
                TenPhong = null,

                MaBacSiKham = phieu.MaBacSiKham,
                TenBacSiKham = phieu.BacSiKham?.HoTen,
                MaNguoiLap = phieu.MaNguoiLap,
                TenNguoiLap = phieu.NguoiLap?.HoTen,

                MaDichVuKham = phieu.MaDichVuKham,
                TenDichVuKham = dv?.TenDichVu ?? "",
                LoaiDichVu = dv?.LoaiDichVu ?? "",
                PhiDV = dv?.DonGia.ToString("0") ?? "0",

                MaLichHen = phieu.MaLichHen,
                LoaiHen = lichHen?.LoaiHen,
                MaPhieuKqKhamCls = phieu.MaPhieuKqKhamCls,

                HinhThucTiepNhan = phieu.HinhThucTiepNhan,
                NgayLap = phieu.NgayLap,
                GioLap = phieu.GioLap,
                TrieuChung = phieu.TrieuChung,

                // Gộp toàn bộ thông tin bệnh sử thành 1 chuỗi
                ThongTinChiTiet = BuildThongTinChiTiet(bn),

                TrangThai = phieu.TrangThai
            };
        }

        // ================== 1. TẠO PHIẾU KHÁM ==================

        public async Task<ClinicalExamDto> TaoPhieuKhamAsync(ClinicalExamCreateRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.MaBenhNhan))
                throw new ArgumentException("MaBenhNhan là bắt buộc");
            if (string.IsNullOrWhiteSpace(request.MaBacSiKham))
                throw new ArgumentException("MaBacSiKham là bắt buộc");
            if (string.IsNullOrWhiteSpace(request.MaNguoiLap))
                throw new ArgumentException("MaNguoiLap là bắt buộc");
            if (string.IsNullOrWhiteSpace(request.MaDichVuKham))
                throw new ArgumentException("MaDichVuKham là bắt buộc");

            var benhNhan = await _db.BenhNhans
                .FirstOrDefaultAsync(b => b.MaBenhNhan == request.MaBenhNhan)
                    ?? throw new InvalidOperationException("Không tìm thấy bệnh nhân");

            // Cập nhật hồ sơ bệnh nhân từ 8 field chi tiết
            if (request.DiUng is not null) benhNhan.DiUng = request.DiUng;
            if (request.ChongChiDinh is not null) benhNhan.ChongChiDinh = request.ChongChiDinh;
            if (request.ThuocDangDung is not null) benhNhan.ThuocDangDung = request.ThuocDangDung;
            if (request.TieuSuBenh is not null) benhNhan.TieuSuBenh = request.TieuSuBenh;
            if (request.TienSuPhauThuat is not null) benhNhan.TienSuPhauThuat = request.TienSuPhauThuat;
            if (request.NhomMau is not null) benhNhan.NhomMau = request.NhomMau;
            if (request.BenhManTinh is not null) benhNhan.BenhManTinh = request.BenhManTinh;
            if (request.SinhHieu is not null) benhNhan.SinhHieu = request.SinhHieu;

            var now = DateTime.Now;
            var ngay = request.NgayLap?.Date ?? now.Date;
            var gio = request.GioLap ?? now.TimeOfDay;

            // ===== 1. Kiểm tra lịch hẹn + tính phân loại đến (nếu có) =====
            DateTime? thoiGianLichHen = null;
            string? phanLoaiDen = null;
            // PATCH: giữ lại LoaiHen để gắn vào Nhan của queue
            string? loaiHen = null;
            if (!string.IsNullOrWhiteSpace(request.MaLichHen))
            {
                var lichHen = await _db.LichHenKhams
                    .FirstOrDefaultAsync(l => l.MaLichHen == request.MaLichHen)
                        ?? throw new InvalidOperationException("Không tìm thấy lịch hẹn");

                if (!lichHen.CoHieuLuc || lichHen.TrangThai != "da_checkin")
                    throw new InvalidOperationException("Lịch hẹn không còn hiệu lực hoặc chưa được check-in");
                loaiHen = lichHen.LoaiHen;
                // Nếu lịch hẹn đã gán bệnh nhân thì phải khớp
                if (!string.IsNullOrEmpty(lichHen.MaBenhNhan) &&
                    !string.Equals(lichHen.MaBenhNhan, request.MaBenhNhan, StringComparison.OrdinalIgnoreCase))
                {
                    throw new InvalidOperationException("Lịch hẹn không thuộc về bệnh nhân này");
                }

                // Nếu lịch hẹn chưa gán MaBenhNhan thì gán lại
                if (string.IsNullOrEmpty(lichHen.MaBenhNhan))
                {
                    lichHen.MaBenhNhan = request.MaBenhNhan;
                }

                thoiGianLichHen = lichHen.NgayHen.Date + lichHen.GioHen;

                var diff = now - thoiGianLichHen.Value; // >0: đến trễ
                if (diff.TotalMinutes > 30)
                    phanLoaiDen = "den_muon";
                else if (diff.TotalMinutes < -15)
                    phanLoaiDen = "den_som";
                else
                    phanLoaiDen = "dung_gio";
            }

            // ===== 2. Load dịch vụ khám để lấy phòng thực hiện =====
            var dichVuKham = await _db.DichVuYTes
                .AsNoTracking()
                .FirstOrDefaultAsync(d => d.MaDichVu == request.MaDichVuKham)
                    ?? throw new InvalidOperationException("Không tìm thấy dịch vụ khám");

            var maPhongKham = dichVuKham.MaPhongThucHien
                ?? throw new InvalidOperationException("Dịch vụ khám chưa cấu hình phòng thực hiện");

            // ===== 3. Rule: 1 bệnh nhân chỉ 1 phiếu LS đang hoạt động =====
            var existingActive = await _db.PhieuKhamLamSangs
                .Include(p => p.BenhNhan)
                .Include(p => p.DichVuKham)
                .Include(p => p.BacSiKham)
                .Include(p => p.NguoiLap)
                .Include(p => p.LichHenKham)
                .FirstOrDefaultAsync(p =>
                    p.MaBenhNhan == request.MaBenhNhan &&
                    p.TrangThai != "da_hoan_tat" &&
                    p.TrangThai != "da_huy");

            PhieuKhamLamSang phieuInUse;

            if (existingActive is not null)
            {
                // Cập nhật phiếu cũ theo request mới
                existingActive.MaBacSiKham = request.MaBacSiKham;
                existingActive.MaNguoiLap = request.MaNguoiLap;
                existingActive.MaDichVuKham = request.MaDichVuKham;
                existingActive.MaLichHen = request.MaLichHen;
                existingActive.TrieuChung = request.TrieuChung ?? existingActive.TrieuChung;
                existingActive.NgayLap = ngay;
                existingActive.GioLap = gio;

                phieuInUse = existingActive;
            }
            else
            {
                // Không có phiếu đang hoạt động -> tạo phiếu mới
                phieuInUse = new PhieuKhamLamSang
                {
                    MaPhieuKham = $"PKLS-{Guid.NewGuid():N}",
                    MaBenhNhan = benhNhan.MaBenhNhan,
                    MaBacSiKham = request.MaBacSiKham,
                    MaNguoiLap = request.MaNguoiLap,
                    MaDichVuKham = request.MaDichVuKham,
                    MaLichHen = request.MaLichHen,
                    NgayLap = ngay,
                    GioLap = gio,
                    TrieuChung = request.TrieuChung,
                    TrangThai = "da_lap"
                };

                _db.PhieuKhamLamSangs.Add(phieuInUse);
            }

            // ===== 4. Xác định HinhThucTiepNhan theo rule anh yêu cầu =====
            string hinhThucTiepNhan;

            if (!string.IsNullOrWhiteSpace(phieuInUse.MaPhieuKqKhamCls))
            {
                // Có mã phiếu tổng hợp kết quả CLS (phiếu cũ) -> tái khám / service_return
                hinhThucTiepNhan = "service_return";
            }
            else if (!string.IsNullOrWhiteSpace(phieuInUse.MaLichHen))
            {
                // Có mã lịch hẹn -> appointment
                hinhThucTiepNhan = "appointment";
            }
            else
            {
                // Còn lại -> walkin
                hinhThucTiepNhan = "walkin";
            }

            phieuInUse.HinhThucTiepNhan = hinhThucTiepNhan;

            await _db.SaveChangesAsync();

            // ===== 5. Đẩy vào queue phòng khám =====
            var enqueueRequest = new QueueEnqueueRequest
            {
                MaBenhNhan = benhNhan.MaBenhNhan,
                MaPhong = maPhongKham,
                LoaiHangDoi = "kham_ls",                // queue khám lâm sàng
                Nguon = hinhThucTiepNhan,              // 🔥 walkin / appointment / service_return
                Nhan = loaiHen,
                CapCuu = false,
                DoUuTien = 0,                          // BE QueueService sẽ tự tính
                ThoiGianLichHen = thoiGianLichHen,
                MaPhieuKham = phieuInUse.MaPhieuKham,
                MaChiTietDv = null,
                PhanLoaiDen = phanLoaiDen             // tái sử dụng phân loại đến nếu có lịch hẹn
            };

            await _queue.ThemVaoHangDoiAsync(enqueueRequest);

            // ===== 6. Load lại phiếu để map DTO + realtime, dashboard, notify =====
            var loaded = await _db.PhieuKhamLamSangs
                .AsNoTracking()
                .Include(p => p.BenhNhan)
                .Include(p => p.DichVuKham)
                .Include(p => p.BacSiKham)
                .Include(p => p.NguoiLap)
                .Include(p => p.LichHenKham)
                .FirstAsync(p => p.MaPhieuKham == phieuInUse.MaPhieuKham);

            var dto = MapClinicalExam(loaded);

            await _realtime.BroadcastClinicalExamCreatedAsync(dto);
            await TaoThongBaoPhieuKhamMoiAsync(dto);

            var dashboard = await _dashboard.LayDashboardHomNayAsync();
            await _realtime.BroadcastTodayPatientsKpiAsync(dashboard.BenhNhanTrongNgay);
            await _realtime.BroadcastTodayExamOverviewAsync(dashboard.LuotKhamHomNay);
            await _realtime.BroadcastRecentActivitiesAsync(dashboard.HoatDongGanDay);

            return dto;
        }


        // ================== 2. LẤY PHIẾU KHÁM ==================

        public async Task<ClinicalExamDto?> LayPhieuKhamAsync(string maPhieuKham)
        {
            if (string.IsNullOrWhiteSpace(maPhieuKham)) return null;

            var phieu = await _db.PhieuKhamLamSangs
                .AsNoTracking()
                .Include(p => p.BenhNhan)
                .Include(p => p.DichVuKham)
                .Include(p => p.BacSiKham)
                .Include(p => p.NguoiLap)
                .Include(p => p.LichHenKham)
                .FirstOrDefaultAsync(p => p.MaPhieuKham == maPhieuKham);

            return phieu is null ? null : MapClinicalExam(phieu);
        }

        // ================== 3. CẬP NHẬT TRẠNG THÁI PHIẾU ==================

        public async Task<ClinicalExamDto?> CapNhatTrangThaiPhieuKhamAsync(
            string maPhieuKham,
            ClinicalExamStatusUpdateRequest request)
        {
            if (string.IsNullOrWhiteSpace(maPhieuKham)) return null;
            if (string.IsNullOrWhiteSpace(request.TrangThai))
                throw new ArgumentException("TrangThai là bắt buộc");

            var phieu = await _db.PhieuKhamLamSangs
                .Include(p => p.BenhNhan)
                .Include(p => p.DichVuKham)
                .Include(p => p.BacSiKham)
                .Include(p => p.NguoiLap)
                .Include(p => p.LichHenKham)
                .FirstOrDefaultAsync(p => p.MaPhieuKham == maPhieuKham);

            if (phieu is null) return null;

            phieu.TrangThai = request.TrangThai;
            await _db.SaveChangesAsync();

            var dto = MapClinicalExam(phieu);
            await _realtime.BroadcastClinicalExamUpdatedAsync(dto);



            var dashboard = await _dashboard.LayDashboardHomNayAsync();
            await _realtime.BroadcastTodayPatientsKpiAsync(dashboard.BenhNhanTrongNgay);
            await _realtime.BroadcastTodayExamOverviewAsync(dashboard.LuotKhamHomNay);
            await _realtime.BroadcastRecentActivitiesAsync(dashboard.HoatDongGanDay);
            return dto;
        }

        // ================== 4. CHẨN ĐOÁN CUỐI ==================

        public async Task<FinalDiagnosisDto> TaoChanDoanCuoiAsync(
            FinalDiagnosisCreateRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.MaPhieuKham))
                throw new ArgumentException("MaPhieuKham là bắt buộc");

            var phieu = await _db.PhieuKhamLamSangs
    .Include(p => p.BenhNhan)
    .FirstOrDefaultAsync(p => p.MaPhieuKham == request.MaPhieuKham)
        ?? throw new InvalidOperationException("Không tìm thấy phiếu khám");

            var chanDoan = await _db.PhieuChanDoanCuois
                .FirstOrDefaultAsync(c => c.MaPhieuKham == request.MaPhieuKham);

            if (chanDoan is null)
            {
                chanDoan = new PhieuChanDoanCuoi
                {
                    MaPhieuChanDoan = $"PCD-{Guid.NewGuid():N}",
                    MaPhieuKham = request.MaPhieuKham
                };
                _db.PhieuChanDoanCuois.Add(chanDoan);
            }

            chanDoan.MaDonThuoc = request.MaDonThuoc;
            chanDoan.ChanDoanSoBo = request.ChanDoanSoBo;
            chanDoan.ChanDoanCuoi = request.ChanDoanCuoi;
            chanDoan.NoiDungKham = request.NoiDungKham;
            chanDoan.HuongXuTri = request.HuongXuTri;
            chanDoan.LoiKhuyen = request.LoiKhuyen;
            chanDoan.PhatDoDieuTri = request.PhatDoDieuTri;

            await _db.SaveChangesAsync();

            var dto = new FinalDiagnosisDto
            {
                MaPhieuChanDoan = chanDoan.MaPhieuChanDoan,
                MaPhieuKham = chanDoan.MaPhieuKham,
                MaDonThuoc = chanDoan.MaDonThuoc,
                ChanDoanSoBo = chanDoan.ChanDoanSoBo,
                ChanDoanCuoi = chanDoan.ChanDoanCuoi,
                NoiDungKham = chanDoan.NoiDungKham,
                HuongXuTri = chanDoan.HuongXuTri,
                LoiKhuyen = chanDoan.LoiKhuyen,
                PhatDoDieuTri = chanDoan.PhatDoDieuTri
            };

            await _realtime.BroadcastFinalDiagnosisChangedAsync(dto);
          
            var dashboard = await _dashboard.LayDashboardHomNayAsync();
            await _realtime.BroadcastTodayPatientsKpiAsync(dashboard.BenhNhanTrongNgay);
            await _realtime.BroadcastTodayExamOverviewAsync(dashboard.LuotKhamHomNay);
            await _realtime.BroadcastRecentActivitiesAsync(dashboard.HoatDongGanDay);
            await TaoThongBaoPhieuChuanDoanAsync(dto, phieu);
            return dto;
        }

        public async Task<FinalDiagnosisDto?> LayChanDoanCuoiAsync(string maPhieuKham)
        {
            if (string.IsNullOrWhiteSpace(maPhieuKham)) return null;

            var chanDoan = await _db.PhieuChanDoanCuois
                .AsNoTracking()
                .FirstOrDefaultAsync(c => c.MaPhieuKham == maPhieuKham);

            if (chanDoan is null) return null;

            return new FinalDiagnosisDto
            {
                MaPhieuChanDoan = chanDoan.MaPhieuChanDoan,
                MaPhieuKham = chanDoan.MaPhieuKham,
                MaDonThuoc = chanDoan.MaDonThuoc,
                ChanDoanSoBo = chanDoan.ChanDoanSoBo,
                ChanDoanCuoi = chanDoan.ChanDoanCuoi,
                NoiDungKham = chanDoan.NoiDungKham,
                HuongXuTri = chanDoan.HuongXuTri,
                LoiKhuyen = chanDoan.LoiKhuyen,
                PhatDoDieuTri = chanDoan.PhatDoDieuTri
            };
        }

        // ================== 5. SEARCH + PAGING ==================

        public async Task<PagedResult<ClinicalExamDto>> TimKiemPhieuKhamAsync(
            string? maBenhNhan,
            string? maBacSi,
            DateTime? fromDate,
            DateTime? toDate,
            string? trangThai,
            int page,
            int pageSize)
        {
            page = page <= 0 ? 1 : page;
            pageSize = pageSize <= 0 ? 20 : pageSize;

            var query = _db.PhieuKhamLamSangs
                .AsNoTracking()
                .Include(p => p.BenhNhan)
                .Include(p => p.DichVuKham)
                .Include(p => p.BacSiKham)
                .Include(p => p.NguoiLap)
                .Include(p => p.LichHenKham)
                .AsQueryable();

            if (!string.IsNullOrWhiteSpace(maBenhNhan))
                query = query.Where(p => p.MaBenhNhan == maBenhNhan);

            if (!string.IsNullOrWhiteSpace(maBacSi))
                query = query.Where(p => p.MaBacSiKham == maBacSi);

            if (fromDate.HasValue)
            {
                var from = fromDate.Value.Date;
                query = query.Where(p => p.NgayLap >= from);
            }

            if (toDate.HasValue)
            {
                var to = toDate.Value.Date.AddDays(1);
                query = query.Where(p => p.NgayLap < to);
            }

            if (!string.IsNullOrWhiteSpace(trangThai))
                query = query.Where(p => p.TrangThai == trangThai);

            query = query.OrderByDescending(p => p.NgayLap)
                         .ThenByDescending(p => p.GioLap);

            var totalItems = await query.CountAsync();
            var items = await query
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            var dtos = items.Select(MapClinicalExam).ToList();

            return new PagedResult<ClinicalExamDto>
            {
                Items = dtos,
                TotalItems = totalItems,
                Page = page,
                PageSize = pageSize
            };
        }
        private async Task TaoThongBaoPhieuKhamMoiAsync(ClinicalExamDto phieu)
        {
            if (phieu == null) return;

            var title = "Phiếu khám lâm sàng mới";
            var body =
                $"Phiếu khám mới cho bệnh nhân {phieu.HoTen} (Mã phiếu: {phieu.MaPhieuKham}).";

            var request = new NotificationCreateRequest
            {
                LoaiThongBao = "phieu_kham",
                TieuDe = title,
                NoiDung = body,
                MucDoUuTien = "normal",

                // Map vào nguồn liên quan, NotificationService đang hỗ trợ "phieu_kham"
                NguonLienQuan = "phieu_kham",
                MaDoiTuongLienQuan = phieu.MaPhieuKham,

                // Gửi cho toàn bộ nhân sự y tế (bác sĩ + y tá)
                NguoiNhan = new List<NotificationRecipientCreateRequest>
                {
                    new NotificationRecipientCreateRequest
                    {
                        LoaiNguoiNhan =  "bac_si",
                        MaNguoiNhan = phieu.MaBacSiKham
                    }
                }
            };

            await _notifications.TaoThongBaoAsync(request);
        }
        private async Task TaoThongBaoPhieuChuanDoanAsync(
    FinalDiagnosisDto chanDoan,
    PhieuKhamLamSang phieu
)
        {
            if (chanDoan == null) return;
            if (phieu == null) return;
            if (string.IsNullOrWhiteSpace(phieu.MaBenhNhan)) return;

            // Lấy tên bệnh nhân nếu có
            var tenBenhNhan = phieu.BenhNhan?.HoTen;
            if (string.IsNullOrWhiteSpace(tenBenhNhan))
            {
                tenBenhNhan = await _db.BenhNhans
                    .Where(b => b.MaBenhNhan == phieu.MaBenhNhan)
                    .Select(b => b.HoTen)
                    .FirstOrDefaultAsync() ?? "bệnh nhân";
            }

            var title = "Kết quả khám & chẩn đoán cuối";
            var body =
                $"Kết quả khám và chẩn đoán cuối của bệnh nhân ({tenBenhNhan}) " +
                $"cho phiếu khám {phieu.MaPhieuKham} đã được cập nhật. ";

            var request = new NotificationCreateRequest
            {
                LoaiThongBao = "phieu_chan_doan",   // loại thông báo để FE lọc
                TieuDe = title,
                NoiDung = body,
                MucDoUuTien = "normal",

                // Gắn nguồn liên quan về phiếu khám để sau này có thể deep-link
                NguonLienQuan = "phieu_kham",
                MaDoiTuongLienQuan = phieu.MaPhieuKham,

             
                NguoiNhan = new List<NotificationRecipientCreateRequest>
        {
            new NotificationRecipientCreateRequest
            {
                LoaiNguoiNhan = "y_ta",
                MaNguoiNhan = null
            }
        }
            };

            await _notifications.TaoThongBaoAsync(request);
        }

       

    }
}
