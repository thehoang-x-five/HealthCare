﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HealthCare.Datas;
using HealthCare.DTOs;
using HealthCare.Entities;
using HealthCare.RenderID;
using HealthCare.Realtime;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Routing.Matching;

namespace HealthCare.Services
{
    public class QueueService(DataContext db, IRealtimeService realtime, IPatientService patients) : IQueueService
    {
        private readonly DataContext _db = db;
        private readonly IRealtimeService _realtime = realtime;
        private readonly IPatientService _patients = patients;
        // ====== Helper: phân loại đến theo lịch hẹn ======
        private static string? TinhPhanLoaiDen(DateTime now, DateTime? lichHen)
        {
            if (!lichHen.HasValue) return null;

            var diff = now - lichHen.Value; // >0: đến trễ

            if (diff.TotalMinutes > 30)
                return "den_muon";
            if (diff.TotalMinutes < -15)
                return "den_som";

            return "dung_gio";
        }

        /// <summary>
        /// BE tự tính độ ưu tiên:
        /// - CapCuu           -> group 0
        /// - service_return   -> group 1
        /// - appointment      -> group 2 (trừ khi đến muộn >30p thì xuống group 3)
        /// - walkin/khác      -> group 3
        /// DoUuTien = group * 10
        /// </summary>
        public int TinhDoUuTien(QueueEnqueueRequest request)
        {
            // 1. Cấp cứu luôn trên hết
            if (request.CapCuu)
                return 0; // group 0

            var source = (request.Nguon ?? string.Empty).ToLowerInvariant();
            int group;

            switch (source)
            {
                case "service_return":
                    group = 1;
                    break;

                case "appointment":
                    // Appointment đến muộn >30p => coi như walkin
                    if (string.Equals(request.PhanLoaiDen, "den_muon", StringComparison.OrdinalIgnoreCase))
                        group = 3;
                    else
                        group = 2;
                    break;

                default:
                    group = 3; // walkin / unknown
                    break;
            }

            return group * 10;
        }

        // ====== THÊM VÀO HÀNG ĐỢI ======
        public async Task<QueueItemDto> ThemVaoHangDoiAsync(QueueEnqueueRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.MaBenhNhan))
                throw new ArgumentException("MaBenhNhan là bắt buộc");
            if (string.IsNullOrWhiteSpace(request.MaPhong))
                throw new ArgumentException("MaPhong là bắt buộc");
            if (string.IsNullOrWhiteSpace(request.LoaiHangDoi))
                throw new ArgumentException("LoaiHangDoi là bắt buộc");
            if (string.IsNullOrWhiteSpace(request.Nguon))
                throw new ArgumentException("Nguon là bắt buộc");

            // Kiểm tra tồn tại cơ bản
            var bnExists = await _db.BenhNhans
                .AnyAsync(b => b.MaBenhNhan == request.MaBenhNhan);
            if (!bnExists)
                throw new ArgumentException($"Không tìm thấy bệnh nhân {request.MaBenhNhan}");

            var phongExists = await _db.Phongs
                .AnyAsync(p => p.MaPhong == request.MaPhong);
            if (!phongExists)
                throw new ArgumentException($"Không tìm thấy phòng {request.MaPhong}");

            var now = DateTime.Now;

            // 🔁 Ưu tiên dùng phân loại đến đã được tính sẵn (nếu có)
            var phanLoaiDen = request.PhanLoaiDen;

            if (string.IsNullOrWhiteSpace(phanLoaiDen))
            {
                // Fallback: nếu BE không được truyền vào thì tự tính như cũ
                phanLoaiDen = TinhPhanLoaiDen(now, request.ThoiGianLichHen);
            }
            request.PhanLoaiDen = phanLoaiDen;
            // BE tự tính độ ưu tiên từ Nguon + CapCuu + phanLoaiDen
            var doUuTien = TinhDoUuTien(request);

            var entity = new HangDoi
            {
                MaHangDoi = GeneratorID.NewHangDoiId(),
                MaBenhNhan = request.MaBenhNhan,
                MaPhong = request.MaPhong,
                LoaiHangDoi = request.LoaiHangDoi,
                Nguon = request.Nguon,
                Nhan = request.Nhan,
                CapCuu = request.CapCuu,
                PhanLoaiDen = phanLoaiDen,
                ThoiGianCheckin = now,
                ThoiGianLichHen = request.ThoiGianLichHen,
                DoUuTien = doUuTien,
                TrangThai = "cho_goi",
                GhiChu = null,
                MaPhieuKham = request.MaPhieuKham,
                MaChiTietDv = request.MaChiTietDv
            };

            _db.HangDois.Add(entity);
            await _db.SaveChangesAsync();
            // 🔥 Cập nhật trạng thái hôm nay của bệnh nhân bằng PatientService
                // để tận dụng realtime + notification
                if (request.LoaiHangDoi == "kham_ls")
                    {
                await _patients.CapNhatTrangThaiBenhNhanAsync(
                request.MaBenhNhan,
                new PatientStatusUpdateRequest
                            {
                    TrangThaiHomNay = "cho_kham"
                                });
                    }
            var saved = await _db.HangDois
                .AsNoTracking()
                .FirstAsync(h => h.MaHangDoi == entity.MaHangDoi);

            var dto = MapToDto(saved);

            // Realtime: cập nhật phòng + item
            var roomItems = await LayHangDoiTheoPhongAsync(dto.MaPhong);
            await _realtime.BroadcastQueueByRoomAsync(dto.MaPhong, roomItems);
            await _realtime.BroadcastQueueItemChangedAsync(dto);

            return dto;
        }

        public async Task<QueueItemDto?> LayHangDoiAsync(string maHangDoi)
        {
            var entity = await _db.HangDois
                .AsNoTracking()
                .FirstOrDefaultAsync(h => h.MaHangDoi == maHangDoi);

            return entity is null ? null : MapToDto(entity);
        }

        public async Task<IReadOnlyList<QueueItemDto>> LayHangDoiTheoPhongAsync(
            string maPhong,
            string? loaiHangDoi = null,
            string? trangThai = null)
        {
            var query = _db.HangDois
                .AsNoTracking()
                .Where(h => h.MaPhong == maPhong);

            if (!string.IsNullOrWhiteSpace(loaiHangDoi))
                query = query.Where(h => h.LoaiHangDoi == loaiHangDoi);

            if (!string.IsNullOrWhiteSpace(trangThai))
                query = query.Where(h => h.TrangThai == trangThai);

            var list = await query.ToListAsync();

            var ordered = list
                .OrderBy(h => h.DoUuTien) // group: 0,10,20,30
                .ThenBy(h =>
                {
                    var isAppt = string.Equals(h.Nguon, "appointment", StringComparison.OrdinalIgnoreCase);
                    var isLate = string.Equals(h.PhanLoaiDen, "den_muon", StringComparison.OrdinalIgnoreCase);

                    // Appointment đúng giờ / sớm vừa phải -> xếp theo giờ hẹn
                    if (isAppt && !isLate && h.ThoiGianLichHen.HasValue)
                        return h.ThoiGianLichHen.Value;

                    // Còn lại (appointment đến sớm >15, đến muộn, walkin, service_return…) -> theo checkin
                    return h.ThoiGianCheckin;
                })
                .Select(MapToDto)
                .ToList();

            return ordered;
        }

        public async Task<QueueItemDto?> CapNhatTrangThaiHangDoiAsync(
            string maHangDoi,
            QueueStatusUpdateRequest request)
        {
            var entity = await _db.HangDois
                .FirstOrDefaultAsync(h => h.MaHangDoi == maHangDoi);

            if (entity is null)
                return null;

            entity.TrangThai = request.TrangThai;
            await _db.SaveChangesAsync();

            var dto = MapToDto(entity);

            var roomItems = await LayHangDoiTheoPhongAsync(dto.MaPhong);
            await _realtime.BroadcastQueueByRoomAsync(dto.MaPhong, roomItems);
            await _realtime.BroadcastQueueItemChangedAsync(dto);

            return dto;
        }

        public async Task<QueueItemDto?> LayTiepTheoTrongPhongAsync(
            string maPhong,
            string? loaiHangDoi = null)
        {
            var query = _db.HangDois
                .Where(h => h.MaPhong == maPhong && h.TrangThai == "cho_goi");

            if (!string.IsNullOrWhiteSpace(loaiHangDoi))
                query = query.Where(h => h.LoaiHangDoi == loaiHangDoi);

            var list = await query.ToListAsync();
            if (!list.Any())
                return null;

            var next = list
                .OrderBy(h => h.DoUuTien)
                .ThenBy(h =>
                {
                    var isAppt = string.Equals(h.Nguon, "appointment", StringComparison.OrdinalIgnoreCase);
                    var isLate = string.Equals(h.PhanLoaiDen, "den_muon", StringComparison.OrdinalIgnoreCase);

                    if (isAppt && !isLate && h.ThoiGianLichHen.HasValue)
                        return h.ThoiGianLichHen.Value;

                    return h.ThoiGianCheckin;
                })
                .First();

            next.TrangThai = "dang_goi";
            await _db.SaveChangesAsync();

            var dto = MapToDto(next);

            var roomItems = await LayHangDoiTheoPhongAsync(dto.MaPhong);
            await _realtime.BroadcastQueueByRoomAsync(dto.MaPhong, roomItems);
            await _realtime.BroadcastQueueItemChangedAsync(dto);

            return dto;
        }

        public async Task<PagedResult<QueueItemDto>> TimKiemHangDoiAsync(QueueSearchFilter filter)
        {
            var query = _db.HangDois.AsNoTracking().AsQueryable();

            if (!string.IsNullOrWhiteSpace(filter.MaPhong))
                query = query.Where(h => h.MaPhong == filter.MaPhong);

            if (!string.IsNullOrWhiteSpace(filter.LoaiHangDoi))
                query = query.Where(h => h.LoaiHangDoi == filter.LoaiHangDoi);

            if (!string.IsNullOrWhiteSpace(filter.TrangThai))
                query = query.Where(h => h.TrangThai == filter.TrangThai);

            if (filter.FromTime.HasValue)
                query = query.Where(h => h.ThoiGianCheckin >= filter.FromTime.Value);

            if (filter.ToTime.HasValue)
                query = query.Where(h => h.ThoiGianCheckin <= filter.ToTime.Value);

            var sortBy = filter.SortBy?.ToLowerInvariant();
            var sortDir = (filter.SortDirection ?? "asc").ToLowerInvariant();

            query = (sortBy, sortDir) switch
            {
                ("douutien", "desc") => query.OrderByDescending(h => h.DoUuTien)
                                              .ThenBy(h => h.ThoiGianCheckin),
                ("douutien", _) => query.OrderBy(h => h.DoUuTien)
                                              .ThenBy(h => h.ThoiGianCheckin),

                ("thoigianlichhen", "desc") => query.OrderByDescending(h => h.ThoiGianLichHen)
                                                    .ThenBy(h => h.ThoiGianCheckin),
                ("thoigianlichhen", _) => query.OrderBy(h => h.ThoiGianLichHen)
                                                    .ThenBy(h => h.ThoiGianCheckin),

                ("thoigiancheckin", "desc") => query.OrderByDescending(h => h.ThoiGianCheckin),
                ("thoigiancheckin", _) => query.OrderBy(h => h.ThoiGianCheckin),

                _ when sortDir == "desc" => query.OrderByDescending(h => h.DoUuTien)
                                                    .ThenBy(h => h.ThoiGianCheckin),
                _ => query.OrderBy(h => h.DoUuTien)
                                                    .ThenBy(h => h.ThoiGianCheckin)
            };

            var page = filter.Page <= 0 ? 1 : filter.Page;
            var pageSize = filter.PageSize <= 0 ? 50 : filter.PageSize;

            var total = await query.CountAsync();

            var list = await query
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            var items = list.Select(MapToDto).ToList();

            return new PagedResult<QueueItemDto>
            {
                Items = items,
                TotalItems = total,
                Page = page,
                PageSize = pageSize
            };
        }

        private static QueueItemDto MapToDto(HangDoi h)
        {
            return new QueueItemDto
            {
                MaHangDoi = h.MaHangDoi,
                MaBenhNhan = h.MaBenhNhan,
                MaPhong = h.MaPhong,
                LoaiHangDoi = h.LoaiHangDoi,
                Nguon = h.Nguon,
                Nhan = h.Nhan,
                CapCuu = h.CapCuu,
                PhanLoaiDen = h.PhanLoaiDen,
                ThoiGianCheckin = h.ThoiGianCheckin,
                ThoiGianLichHen = h.ThoiGianLichHen,
                DoUuTien = h.DoUuTien,
                TrangThai = h.TrangThai,
                MaPhieuKham = h.MaPhieuKham,
                MaChiTietDv = h.MaChiTietDv
            };
        }
    }
}
