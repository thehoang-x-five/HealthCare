﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using HealthCare.Datas;
using HealthCare.DTOs;
using HealthCare.Entities;
using Microsoft.EntityFrameworkCore;
using HealthCare.Realtime;
using HealthCare.Services;
using Microsoft.Extensions.Hosting;
namespace HealthCare.Services
{
    /// <summary>
    /// Service quản lý phiếu CLS, chi tiết DV, kết quả và phiếu tổng hợp.
    /// </summary>
    public class ClsService(DataContext db, IRealtimeService realtime, INotificationService notifications,
    IDashboardService dashboard,
        IPatientService patients) : IClsService
    {
        private readonly DataContext _db = db;
        private readonly IRealtimeService _realtime = realtime;
        private readonly INotificationService _notifications = notifications;
        private readonly IDashboardService _dashboard = dashboard;
        private readonly IPatientService _patients = patients;

        // ================== HELPER ==================

        private static string? BuildThongTinChiTiet(BenhNhan bn)
        {
            var parts = new List<string>();

            void Add(string label, string? value)
            {
                if (!string.IsNullOrWhiteSpace(value))
                    parts.Add($"{label}: {value}");
            }

            Add("Dị ứng", bn.DiUng);
            Add("Chống chỉ định", bn.ChongChiDinh);
            Add("Thuốc đang dùng", bn.ThuocDangDung);
            Add("Tiền sử bệnh", bn.TieuSuBenh);
            Add("Tiền sử phẫu thuật", bn.TienSuPhauThuat);
            Add("Nhóm máu", bn.NhomMau);
            Add("Bệnh mạn tính", bn.BenhManTinh);
            Add("Sinh hiệu", bn.SinhHieu);

            return parts.Count == 0 ? null : string.Join(" | ", parts);
        }

        private static ClsItemDto MapClsItem(ChiTietDichVu c)
        {
            var dv = c.DichVuYTe;

            return new ClsItemDto
            {
                MaChiTietDv = c.MaChiTietDv,
                MaPhieuKhamCls = c.MaPhieuKhamCls,
                MaDichVu = c.MaDichVu,
                TenDichVu = dv?.TenDichVu ?? "",
                LoaiDichVu = dv?.LoaiDichVu ?? "",
                PhiDV = dv?.DonGia.ToString("0") ?? "0",
                GhiChu = c.GhiChu,
                TrangThai = c.TrangThai == "da_hoan_tat" ? "da_co_ket_qua" : "chua_co_ket_qua"
            };
        }

        private async Task<ClsOrderDto?> BuildClsOrderDtoAsync(string maPhieuKhamCls)
        {
            var row =
                await (from cls in _db.PhieuKhamCanLamSangs.AsNoTracking()
                       join ls in _db.PhieuKhamLamSangs.AsNoTracking()
                           on cls.MaPhieuKhamLs equals ls.MaPhieuKham
                       join bn in _db.BenhNhans.AsNoTracking()
                           on ls.MaBenhNhan equals bn.MaBenhNhan
                       where cls.MaPhieuKhamCls == maPhieuKhamCls
                       select new { cls, ls, bn })
                .FirstOrDefaultAsync();

            if (row is null) return null;

            var chiTietList = await _db.ChiTietDichVus
                .AsNoTracking()
                .Where(c => c.MaPhieuKhamCls == maPhieuKhamCls)
                .Include(c => c.DichVuYTe)
                .ToListAsync();

            var itemDtos = chiTietList.Select(MapClsItem).ToList();

            var firstDv = chiTietList.FirstOrDefault()?.DichVuYTe;
            var maPhong = firstDv?.MaPhongThucHien ?? "";

            return new ClsOrderDto
            {
                MaPhieuKhamCls = row.cls.MaPhieuKhamCls,
                MaPhieuKhamLs = row.cls.MaPhieuKhamLs,
                MaBenhNhan = row.bn.MaBenhNhan,

                HoTen = row.bn.HoTen,
                TenBenhNhan = row.bn.HoTen,
                NgaySinh = row.bn.NgaySinh,
                GioiTinh = row.bn.GioiTinh,
                DienThoai = row.bn.DienThoai,
                Email = row.bn.Email,
                DiaChi = row.bn.DiaChi,

                TrangThai = row.cls.TrangThai,
                AutoPublishEnabled = row.cls.AutoPublishEnabled,
                GhiChu = row.cls.GhiChu,
                NgayLap = row.cls.NgayGioLap,
                GioLap = row.cls.NgayGioLap.TimeOfDay,

                MaKhoa = "",
                TenKhoa = null,
                MaPhong = maPhong,
                TenPhong = null,

                MaNguoiLap = row.ls.MaNguoiLap,
                TenNguoiLap = null,

                ThongTinChiTiet = BuildThongTinChiTiet(row.bn),
                ListItemDV = itemDtos
            };
        }

        // ================== 1. PHIẾU CLS ==================

        public async Task<ClsOrderDto> TaoPhieuClsAsync(ClsOrderCreateRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.MaBenhNhan))
                throw new ArgumentException("MaBenhNhan là bắt buộc");
            if (string.IsNullOrWhiteSpace(request.MaPhieuKhamLs))
                throw new ArgumentException("MaPhieuKhamLs là bắt buộc");
            if (string.IsNullOrWhiteSpace(request.MaNguoiLap))
                throw new ArgumentException("MaNguoiLap là bắt buộc");

            // Đảm bảo phiếu CLS luôn gắn với đúng phiếu LS + BN
            var phieuLs = await _db.PhieuKhamLamSangs
                .Include(p => p.BenhNhan)
                .Include(p => p.DichVuKham)
                .FirstOrDefaultAsync(p =>
p.MaPhieuKham == request.MaPhieuKhamLs &&
p.MaBenhNhan == request.MaBenhNhan)
                    ?? throw new InvalidOperationException("Không tìm thấy phiếu khám LS tương ứng");

            var now = DateTime.Now;
            PhieuKhamCanLamSang phieuCls;

            // Transaction: tạo phiếu CLS + chi tiết dịch vụ
            await using (var tx = await _db.Database.BeginTransactionAsync())
            {
                phieuCls = new PhieuKhamCanLamSang
                {
                    MaPhieuKhamCls = $"CLS-{Guid.NewGuid():N}",
                    MaPhieuKhamLs = phieuLs.MaPhieuKham,
                    NgayGioLap = now,
                    AutoPublishEnabled = request.AutoPublishEnabled,
                    TrangThai = request.TrangThai ?? "da_lap",
                    GhiChu = request.GhiChu
                };

_db.PhieuKhamCanLamSangs.Add(phieuCls);
await _db.SaveChangesAsync();

                // Tạo danh sách chi tiết DV nếu có
                if (request.ListItemDV is not null && request.ListItemDV.Count > 0)
                    {
                        foreach (var item in request.ListItemDV)
                            {
                                // Mỗi dòng BS nhập trên UI -> 1 ChiTietDichVu
        var createReq = new ClsItemCreateRequest
                                {
            MaPhieuKhamCls = phieuCls.MaPhieuKhamCls,
MaDichVu = item.MaDichVu,
GhiChu = item.GhiChu,
TrangThai = "chua_co_ket_qua"
                        }
        ;
        
                                // Tái sử dụng hàm có sẵn (tự map + load DichVuYTe)
        await TaoChiTietDichVuAsync(createReq);
                            }
                    }

await tx.CommitAsync();
            }

            // Sau khi chỉ định CLS, trạng thái trong ngày của BN chuyển sang "đang CLS"
            // để FE có thể hiển thị đang trong giai đoạn thực hiện / chờ kết quả CLS.
await _patients.CapNhatTrangThaiBenhNhanAsync(
phieuLs.MaBenhNhan,
new PatientStatusUpdateRequest
                {
    TrangThaiHomNay = "cho_tiep_nhan_dv"
                    });

var dto = await BuildClsOrderDtoAsync(phieuCls.MaPhieuKhamCls)
                ?? throw new InvalidOperationException("Không build được DTO CLS");

            // Realtime: phiếu CLS mới
await _realtime.BroadcastClsOrderCreatedAsync(dto);

           // Thông báo: chỉ định CLS mới
await TaoThongBaoChiDinhClsMoiAsync(dto);

            // Cập nhật Dashboard: lượt khám + hoạt động gần đây
var dashboard = await _dashboard.LayDashboardHomNayAsync();
await _realtime.BroadcastTodayExamOverviewAsync(dashboard.LuotKhamHomNay);
await _realtime.BroadcastRecentActivitiesAsync(dashboard.HoatDongGanDay);

            return dto;
        }

        public Task<ClsOrderDto?> LayPhieuClsAsync(string maPhieuKhamCls)
        {
            if (string.IsNullOrWhiteSpace(maPhieuKhamCls))
                return Task.FromResult<ClsOrderDto?>(null);

            return BuildClsOrderDtoAsync(maPhieuKhamCls);
        }

        public async Task<ClsOrderDto?> CapNhatTrangThaiPhieuClsAsync(string maPhieuKhamCls, string trangThai)
        {
            if (string.IsNullOrWhiteSpace(maPhieuKhamCls))
                return null;
            if (string.IsNullOrWhiteSpace(trangThai))
                throw new ArgumentException("TrangThai là bắt buộc");

            var phieu = await _db.PhieuKhamCanLamSangs
                .FirstOrDefaultAsync(p => p.MaPhieuKhamCls == maPhieuKhamCls);

            if (phieu is null) return null;

            phieu.TrangThai = trangThai;
            await _db.SaveChangesAsync();

            var dto = await BuildClsOrderDtoAsync(maPhieuKhamCls);

            if (dto is not null)
            {
                // Realtime: cập nhật trạng thái phiếu CLS
                await _realtime.BroadcastClsOrderStatusUpdatedAsync(dto);
                // Cập nhật Dashboard: lượt khám + hoạt động gần đây
                var dashboard = await _dashboard.LayDashboardHomNayAsync();
                await _realtime.BroadcastTodayExamOverviewAsync(dashboard.LuotKhamHomNay);
                await _realtime.BroadcastRecentActivitiesAsync(dashboard.HoatDongGanDay);
            }

            return dto;
        }

        // ================== 2. SEARCH + PAGING PHIẾU CLS ==================

        public async Task<PagedResult<ClsOrderDto>> TimKiemPhieuClsAsync(
            string? maBenhNhan,
            string? maBacSi,
            DateTime? fromDate,
            DateTime? toDate,
            string? trangThai,
            int page,
            int pageSize)
        {
            page = page <= 0 ? 1 : page;
            pageSize = pageSize <= 0 ? 20 : pageSize;

            var query =
                from cls in _db.PhieuKhamCanLamSangs.AsNoTracking()
                join ls in _db.PhieuKhamLamSangs.AsNoTracking()
                    on cls.MaPhieuKhamLs equals ls.MaPhieuKham
                join bn in _db.BenhNhans.AsNoTracking()
                    on ls.MaBenhNhan equals bn.MaBenhNhan
                select new { cls, ls, bn };

            if (!string.IsNullOrWhiteSpace(maBenhNhan))
                query = query.Where(x => x.bn.MaBenhNhan == maBenhNhan);

            if (!string.IsNullOrWhiteSpace(maBacSi))
                query = query.Where(x => x.ls.MaBacSiKham == maBacSi);

            if (fromDate.HasValue)
            {
                var from = fromDate.Value.Date;
                query = query.Where(x => x.cls.NgayGioLap >= from);
            }

            if (toDate.HasValue)
            {
                var to = toDate.Value.Date.AddDays(1);
                query = query.Where(x => x.cls.NgayGioLap < to);
            }

            if (!string.IsNullOrWhiteSpace(trangThai))
                query = query.Where(x => x.cls.TrangThai == trangThai);

            query = query.OrderByDescending(x => x.cls.NgayGioLap);

            var totalItems = await query.CountAsync();
            var pageData = await query
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            var maClsList = pageData.Select(x => x.cls.MaPhieuKhamCls).ToList();

            var itemsByHeader = await _db.ChiTietDichVus
                .AsNoTracking()
                .Where(c => maClsList.Contains(c.MaPhieuKhamCls))
                .Include(c => c.DichVuYTe)
                .GroupBy(c => c.MaPhieuKhamCls)
                .ToDictionaryAsync(g => g.Key, g => g.ToList());

            var dtos = new List<ClsOrderDto>();

            foreach (var row in pageData)
            {
                itemsByHeader.TryGetValue(row.cls.MaPhieuKhamCls, out var list);
                var itemDtos = (list ?? [])
                    .Select(MapClsItem)
                    .ToList();

                var firstDv = (list ?? [])
                    .FirstOrDefault()?.DichVuYTe;
                var maPhong = firstDv?.MaPhongThucHien ?? "";

                dtos.Add(new ClsOrderDto
                {
                    MaPhieuKhamCls = row.cls.MaPhieuKhamCls,
                    MaPhieuKhamLs = row.cls.MaPhieuKhamLs,
                    MaBenhNhan = row.bn.MaBenhNhan,

                    HoTen = row.bn.HoTen,
                    TenBenhNhan = row.bn.HoTen,
                    NgaySinh = row.bn.NgaySinh,
                    GioiTinh = row.bn.GioiTinh,
                    DienThoai = row.bn.DienThoai,
                    Email = row.bn.Email,
                    DiaChi = row.bn.DiaChi,

                    TrangThai = row.cls.TrangThai,
                    AutoPublishEnabled = row.cls.AutoPublishEnabled,
                    GhiChu = row.cls.GhiChu,
                    NgayLap = row.cls.NgayGioLap,
                    GioLap = row.cls.NgayGioLap.TimeOfDay,

                    MaKhoa = "",
                    TenKhoa = null,
                    MaPhong = maPhong,
                    TenPhong = null,

                    MaNguoiLap = row.ls.MaNguoiLap,
                    TenNguoiLap = null,

                    ThongTinChiTiet = BuildThongTinChiTiet(row.bn),
                    ListItemDV = itemDtos
                });
            }

            return new PagedResult<ClsOrderDto>
            {
                Items = dtos,
                TotalItems = totalItems,
                Page = page,
                PageSize = pageSize
            };
        }

        // ================== 3. CHI TIẾT DỊCH VỤ ==================

        public async Task<ClsItemDto> TaoChiTietDichVuAsync(ClsItemCreateRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.MaPhieuKhamCls))
                throw new ArgumentException("MaPhieuKhamCls là bắt buộc");
            if (string.IsNullOrWhiteSpace(request.MaDichVu))
                throw new ArgumentException("MaDichVu là bắt buộc");

            var headerExists = await _db.PhieuKhamCanLamSangs
                .AnyAsync(p => p.MaPhieuKhamCls == request.MaPhieuKhamCls);

            if (!headerExists)
                throw new InvalidOperationException("Không tìm thấy phiếu CLS");

            var dichVu = await _db.DichVuYTes
                .FirstOrDefaultAsync(d => d.MaDichVu == request.MaDichVu)
                    ?? throw new InvalidOperationException("Không tìm thấy dịch vụ CLS");

            var chiTiet = new ChiTietDichVu
            {
                MaChiTietDv = $"DV-{Guid.NewGuid():N}",
                MaPhieuKhamCls = request.MaPhieuKhamCls,
                MaDichVu = request.MaDichVu,
                TrangThai = "da_lap",
                GhiChu = request.GhiChu
            };

            _db.ChiTietDichVus.Add(chiTiet);
            await _db.SaveChangesAsync();

            var loaded = await _db.ChiTietDichVus
                .AsNoTracking()
                .Include(c => c.DichVuYTe)
                .FirstAsync(c => c.MaChiTietDv == chiTiet.MaChiTietDv);

            return MapClsItem(loaded);
        }

        public async Task<IReadOnlyList<ClsItemDto>> LayDanhSachDichVuClsAsync(string maPhieuKhamCls)
        {
            var list = await _db.ChiTietDichVus
                .AsNoTracking()
                .Where(c => c.MaPhieuKhamCls == maPhieuKhamCls)
                .Include(c => c.DichVuYTe)
                .ToListAsync();

            return [.. list.Select(MapClsItem)];
        }

        // ================== 4. KẾT QUẢ CLS ==================

        public async Task<ClsResultDto> TaoKetQuaClsAsync(ClsResultCreateRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.MaChiTietDv))
                throw new ArgumentException("MaChiTietDv là bắt buộc");
            if (string.IsNullOrWhiteSpace(request.TrangThaiChot))
                throw new ArgumentException("TrangThaiChot là bắt buộc");
            if (string.IsNullOrWhiteSpace(request.MaNhanSuThucHien))
                throw new ArgumentException("MaNhanSuThucHien là bắt buộc");

            var chiTiet = await _db.ChiTietDichVus
                .Include(c => c.DichVuYTe)
                .FirstOrDefaultAsync(c => c.MaChiTietDv == request.MaChiTietDv)
                    ?? throw new InvalidOperationException("Không tìm thấy chi tiết dịch vụ");

            var ketQua = await _db.KetQuaDichVus
                .FirstOrDefaultAsync(k => k.MaChiTietDv == request.MaChiTietDv);

            var now = DateTime.Now;

            if (ketQua is null)
            {
                ketQua = new KetQuaDichVu
                {
                    MaKetQua = $"KQ-{Guid.NewGuid():N}",
                    MaChiTietDv = chiTiet.MaChiTietDv,
                    TrangThaiChot = request.TrangThaiChot,
                    NoiDungKetQua = request.NoiDungKetQua ?? "",
                    MaNguoiTao = request.MaNhanSuThucHien,
                    ThoiGianTao = now,
                    TepDinhKem = request.TepDinhKem
                };
                _db.KetQuaDichVus.Add(ketQua);
            }
            else
            {
                ketQua.TrangThaiChot = request.TrangThaiChot;
                ketQua.NoiDungKetQua = request.NoiDungKetQua ?? "";
                ketQua.MaNguoiTao = request.MaNhanSuThucHien;
                ketQua.TepDinhKem = request.TepDinhKem;
            }

            chiTiet.TrangThai = "da_hoan_tat";

            await _db.SaveChangesAsync();

            await _db.Entry(ketQua).Reference(k => k.NhanVienYTes).LoadAsync();

            var dto = new ClsResultDto
            {
                MaKetQua = ketQua.MaKetQua,
                MaChiTietDv = ketQua.MaChiTietDv,
                MaPhieuKhamCls = chiTiet.MaPhieuKhamCls,
                MaDichVu = chiTiet.MaDichVu,
                TenDichVu = chiTiet.DichVuYTe?.TenDichVu ?? "",
                TrangThaiChot = ketQua.TrangThaiChot,
                NoiDungKetQua = ketQua.NoiDungKetQua,
                MaNhanSuThucHien = ketQua.MaNguoiTao,
                TenNhanSuThucHien = ketQua.NhanVienYTes?.HoTen ?? "",
                ThoiGianTao = ketQua.ThoiGianTao,
                TepDinhKem = ketQua.TepDinhKem
            };

            // Realtime: có kết quả CLS mới
            await _realtime.BroadcastClsResultCreatedAsync(dto);
            // AUTO PUBLISH: nếu DV cuối cùng đã xong thì tự lập phiếu tổng hợp
            await TryAutoPublishTongHopIfCompletedAsync(chiTiet.MaPhieuKhamCls);

            return dto;
        }

        public async Task<IReadOnlyList<ClsResultDto>> LayKetQuaTheoPhieuClsAsync(string maPhieuKhamCls)
        {
            var list = await _db.KetQuaDichVus
                .AsNoTracking()
                .Include(k => k.NhanVienYTes)
                .Include(k => k.ChiTietDichVu)
                    .ThenInclude(ct => ct.DichVuYTe)
                .Where(k => k.ChiTietDichVu.MaPhieuKhamCls == maPhieuKhamCls)
                .ToListAsync();

            return [.. list.Select(k => new ClsResultDto
            {
                MaKetQua = k.MaKetQua,
                MaChiTietDv = k.MaChiTietDv,
                MaPhieuKhamCls = k.ChiTietDichVu.MaPhieuKhamCls,
                MaDichVu = k.ChiTietDichVu.MaDichVu,
                TenDichVu = k.ChiTietDichVu.DichVuYTe?.TenDichVu ?? "",
                TrangThaiChot = k.TrangThaiChot,
                NoiDungKetQua = k.NoiDungKetQua,
                MaNhanSuThucHien = k.MaNguoiTao,
                TenNhanSuThucHien = k.NhanVienYTes?.HoTen ?? "",
                ThoiGianTao = k.ThoiGianTao,
                TepDinhKem = k.TepDinhKem
            })];
        }

        // ================== 5. PHIẾU TỔNG HỢP KQ CLS ==================

        public async Task<ClsSummaryDto> TaoTongHopAsync(string maPhieuKhamCls)
        {
            if (string.IsNullOrWhiteSpace(maPhieuKhamCls))
                throw new ArgumentException("MaPhieuKhamCls là bắt buộc");

            var phieuCls = await _db.PhieuKhamCanLamSangs
                .Include(p => p.PhieuKhamLamSang)
                    .ThenInclude(ls => ls.BenhNhan)
                .FirstOrDefaultAsync(p => p.MaPhieuKhamCls == maPhieuKhamCls)
                    ?? throw new InvalidOperationException("Không tìm thấy phiếu CLS");

            var phieuLs = phieuCls.PhieuKhamLamSang
                ?? throw new InvalidOperationException("Phiếu CLS không gắn với phiếu khám LS");

            var bn = phieuLs.BenhNhan;
            var clsResults = await LayKetQuaTheoPhieuClsAsync(maPhieuKhamCls);

            var snapshotObj = new
            {
                PhieuCls = new
                {
                    phieuCls.MaPhieuKhamCls,
                    phieuCls.MaPhieuKhamLs,
                    phieuCls.NgayGioLap,
                    phieuCls.TrangThai,
                    phieuCls.GhiChu
                },
                BenhNhan = new
                {
                    bn.MaBenhNhan,
                    bn.HoTen,
                    bn.NgaySinh,
                    bn.GioiTinh,
                    bn.DienThoai,
                    bn.DiaChi
                },
                KetQua = clsResults
            };

            var snapshotJson = JsonSerializer.Serialize(snapshotObj);
            var now = DateTime.Now;

            var summary = await _db.PhieuTongHopKetQuas
                .FirstOrDefaultAsync(s => s.MaPhieuKhamCls == maPhieuKhamCls);

            var isNew = summary is null;

            if (summary is null)
            {
                summary = new PhieuTongHopKetQua
                {
                    MaPhieuTongHop = $"THKQ-{Guid.NewGuid():N}",
                    MaPhieuKhamCls = maPhieuKhamCls,
                    LoaiPhieu = "tong_hop_cls",
                    TrangThai = "cho_xu_ly",
                    ThoiGianXuLy = now,
                    SnapshotJson = snapshotJson
                };
                _db.PhieuTongHopKetQuas.Add(summary);
            }
            else
            {
                summary.SnapshotJson = snapshotJson;
                summary.ThoiGianXuLy = now;
            }

            // ===== PATCH: gắn mã phiếu tổng hợp vào lại phiếu khám LS =====
            phieuLs.MaPhieuKqKhamCls = summary.MaPhieuTongHop;

            // Đây là thời điểm "lấy lại phiếu LS cũ đó đẩy lại vào queue phòng khám".
            // Nếu queue phòng khám của anh dựa trên trạng thái phiếu LS:
            //   - Có thể chỉnh về trạng thái chờ khám lại, ví dụ "da_lap" (tùy nghiệp vụ).
            // Ví dụ (chỉ là gợi ý, anh sửa theo rule thực tế):
            // if (phieuLs.TrangThai == "dang_kham")
            // {
            //     phieuLs.TrangThai = "da_lap";
            // }

            // Nếu anh có bảng HangDoi / Queue riêng cho phòng khám thì có thể gọi
            // 1 hàm re-enqueue tại đây, ví dụ:
            // await RequeueClinicalExamToClinicAsync(phieuLs);
            // (em không đoán schema HangDoi nên để TODO cho anh tự map cho đúng)
            // ===== HẾT PATCH =====

            await _db.SaveChangesAsync();

            var dto = new ClsSummaryDto
            {
                MaPhieuTongHop = summary.MaPhieuTongHop,
                MaPhieuKhamCls = summary.MaPhieuKhamCls,
                MaBenhNhan = bn.MaBenhNhan,
                TenBenhNhan = bn.HoTen,
                NgayGioLapPhieuCls = phieuCls.NgayGioLap,
                ThoiGianXuLy = summary.ThoiGianXuLy,
                TrangThai = summary.TrangThai,
                SnapshotJson = summary.SnapshotJson
            };

            if (isNew)
            {
                await _realtime.BroadcastClsSummaryCreatedAsync(dto);
                // Thông báo: lập phiếu tổng hợp lần đầu
                await TaoThongBaoTongHopClsAsync(dto);
            }
            else
            {
                await _realtime.BroadcastClsSummaryUpdatedAsync(dto);
            }

            return dto;
        }

        public async Task<PagedResult<ClsSummaryDto>> LayTongHopKetQuaChoLapPhieuKhamAsync(ClsSummaryFilter filter)
        {
            if (string.IsNullOrWhiteSpace(filter.MaBenhNhan))
                throw new ArgumentException("MaBenhNhan là bắt buộc trong filter");

            var page = filter.Page <= 0 ? 1 : filter.Page;
            var pageSize = filter.PageSize <= 0 ? 20 : filter.PageSize;

            var query =
                from s in _db.PhieuTongHopKetQuas.AsNoTracking()
                join cls in _db.PhieuKhamCanLamSangs.AsNoTracking()
                    on s.MaPhieuKhamCls equals cls.MaPhieuKhamCls
                join ls in _db.PhieuKhamLamSangs.AsNoTracking()
                    on cls.MaPhieuKhamLs equals ls.MaPhieuKham
                join bn in _db.BenhNhans.AsNoTracking()
                    on ls.MaBenhNhan equals bn.MaBenhNhan
                where bn.MaBenhNhan == filter.MaBenhNhan
                select new { s, cls, ls, bn };

            if (filter.FromDate.HasValue)
            {
                var from = filter.FromDate.Value.Date;
                query = query.Where(x => x.s.ThoiGianXuLy >= from);
            }

            if (filter.ToDate.HasValue)
            {
                var to = filter.ToDate.Value.Date.AddDays(1);
                query = query.Where(x => x.s.ThoiGianXuLy < to);
            }

            if (!string.IsNullOrWhiteSpace(filter.TrangThai))
                query = query.Where(x => x.s.TrangThai == filter.TrangThai);

            query = query.OrderByDescending(x => x.s.ThoiGianXuLy);

            var totalItems = await query.CountAsync();
            var pageData = await query
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            var dtos = pageData.Select(x => new ClsSummaryDto
            {
                MaPhieuTongHop = x.s.MaPhieuTongHop,
                MaPhieuKhamCls = x.s.MaPhieuKhamCls,
                MaBenhNhan = x.bn.MaBenhNhan,
                TenBenhNhan = x.bn.HoTen,
                NgayGioLapPhieuCls = x.cls.NgayGioLap,
                ThoiGianXuLy = x.s.ThoiGianXuLy,
                TrangThai = x.s.TrangThai,
                SnapshotJson = x.s.SnapshotJson
            }).ToList();

            return new PagedResult<ClsSummaryDto>
            {
                Items = dtos,
                TotalItems = totalItems,
                Page = page,
                PageSize = pageSize
            };
        }

        public async Task<ClsSummaryDto?> LayPhieuTongHopKetQuaAsync(string maPhieuTongHop)
        {
            if (string.IsNullOrWhiteSpace(maPhieuTongHop))
                return null;

            var row =
                await (from s in _db.PhieuTongHopKetQuas.AsNoTracking()
                       join cls in _db.PhieuKhamCanLamSangs.AsNoTracking()
                            on s.MaPhieuKhamCls equals cls.MaPhieuKhamCls
                       join ls in _db.PhieuKhamLamSangs.AsNoTracking()
                            on cls.MaPhieuKhamLs equals ls.MaPhieuKham
                       join bn in _db.BenhNhans.AsNoTracking()
                            on ls.MaBenhNhan equals bn.MaBenhNhan
                       where s.MaPhieuTongHop == maPhieuTongHop
                       select new { s, cls, ls, bn })
                .FirstOrDefaultAsync();

            if (row is null) return null;

            return new ClsSummaryDto
            {
                MaPhieuTongHop = row.s.MaPhieuTongHop,
                MaPhieuKhamCls = row.s.MaPhieuKhamCls,
                MaBenhNhan = row.bn.MaBenhNhan,
                TenBenhNhan = row.bn.HoTen,
                NgayGioLapPhieuCls = row.cls.NgayGioLap,
                ThoiGianXuLy = row.s.ThoiGianXuLy,
                TrangThai = row.s.TrangThai,
                SnapshotJson = row.s.SnapshotJson
            };
        }

        public async Task<ClsSummaryDto?> CapNhatTrangThaiTongHopAsync(
            string maPhieuTongHop,
            ClsSummaryStatusUpdateRequest request)
        {
            if (string.IsNullOrWhiteSpace(maPhieuTongHop))
                return null;
            if (string.IsNullOrWhiteSpace(request.TrangThai))
                throw new ArgumentException("TrangThai là bắt buộc");

            var summary = await _db.PhieuTongHopKetQuas
                .FirstOrDefaultAsync(s => s.MaPhieuTongHop == maPhieuTongHop);

            if (summary is null) return null;

            summary.TrangThai = request.TrangThai;
            summary.ThoiGianXuLy = DateTime.Now;

            await _db.SaveChangesAsync();

            var dto = await LayPhieuTongHopKetQuaAsync(maPhieuTongHop);

            if (dto is not null)
            {
                await _realtime.BroadcastClsSummaryUpdatedAsync(dto);
            }

            return dto;
        }

        public async Task<ClsSummaryDto?> CapNhatPhieuTongHopAsync(
            string maPhieuTongHop,
            ClsSummaryUpdateRequest request)
        {
            if (string.IsNullOrWhiteSpace(maPhieuTongHop))
                return null;

            var summary = await _db.PhieuTongHopKetQuas
                .FirstOrDefaultAsync(s => s.MaPhieuTongHop == maPhieuTongHop);

            if (summary is null) return null;

            if (!string.IsNullOrWhiteSpace(request.TrangThai))
                summary.TrangThai = request.TrangThai;

            if (!string.IsNullOrWhiteSpace(request.MaNhanSuXuLy))
                summary.MaNhanSuXuLy = request.MaNhanSuXuLy; // FE là nguồn chuẩn

            if (request.SnapshotJson is not null)
                summary.SnapshotJson = request.SnapshotJson;

            summary.ThoiGianXuLy = request.ThoiGianXuLy ?? DateTime.Now;

            await _db.SaveChangesAsync();

            var dto = await LayPhieuTongHopKetQuaAsync(maPhieuTongHop);

            if (dto is not null)
            {
                await _realtime.BroadcastClsSummaryUpdatedAsync(dto);
            }

            return dto;
        }
        // ==========================
        // =   THÔNG BÁO - CLS      =
        // ==========================

        // Khi tất cả DV trong 1 phiếu CLS đã có kết quả và AutoPublishEnabled = true
        // thì tự động tạo / cập nhật phiếu tổng hợp + gắn lại vào phiếu khám LS.
        private async Task TryAutoPublishTongHopIfCompletedAsync(string maPhieuKhamCls)
        {
            if (string.IsNullOrWhiteSpace(maPhieuKhamCls))
                return;

            var phieuCls = await _db.PhieuKhamCanLamSangs
                .FirstOrDefaultAsync(p => p.MaPhieuKhamCls == maPhieuKhamCls);

            if (phieuCls is null)
                return;

            if (!phieuCls.AutoPublishEnabled)
                return;

            // Còn chi tiết DV nào chưa hoàn tất không?
            var conChuaHoanTat = await _db.ChiTietDichVus
                .AnyAsync(c =>
                    c.MaPhieuKhamCls == maPhieuKhamCls &&
                    c.TrangThai != "da_hoan_tat");

            if (conChuaHoanTat)
                return;

            // Tất cả DV đã hoàn tất -> chốt phiếu CLS
            phieuCls.TrangThai = "da_hoan_tat";
            await _db.SaveChangesAsync();

            // Lập / cập nhật phiếu tổng hợp
            await TaoTongHopAsync(maPhieuKhamCls);
        }



        private async Task TaoThongBaoChiDinhClsMoiAsync(ClsOrderDto order)
        {
            var request = new NotificationCreateRequest
            {
                LoaiThongBao = "cls",
                TieuDe = "Chỉ định CLS mới",
                NoiDung = RenderThongBaoChiDinhClsMoi(order),
                MucDoUuTien = "normal",

                NguonLienQuan = "phieu_cls",
                MaDoiTuongLienQuan = order.MaPhieuKhamCls,

                // Broadcast cho nhân viên y tế (CLS / điều dưỡng hỗ trợ)
                NguoiNhan = new List<NotificationRecipientCreateRequest>
{
    new NotificationRecipientCreateRequest
    {
        LoaiNguoiNhan = "y_ta",//y_ta can_lam_sang
        MaNguoiNhan = null   // broadcast trong nhóm y_ta
    }
}
            };

            await _notifications.TaoThongBaoAsync(request);
        }

        private static string RenderThongBaoChiDinhClsMoi(ClsOrderDto order)
        {
            var tenBn = string.IsNullOrWhiteSpace(order.TenBenhNhan)
                ? order.MaBenhNhan
                : $"{order.TenBenhNhan} ({order.MaBenhNhan})";

            return $"Có chỉ định cận lâm sàng mới cho bệnh nhân {tenBn}. " +
                   "Vui lòng sắp xếp thực hiện và cập nhật kết quả.";
        }


        private async Task TaoThongBaoTongHopClsAsync(ClsSummaryDto summary)
        {
            var request = new NotificationCreateRequest
            {
                LoaiThongBao = "cls_tong_hop",
                TieuDe = "Phiếu tổng hợp kết quả CLS",
                NoiDung = RenderThongBaoTongHopCls(summary),
                MucDoUuTien = "normal",

                NguonLienQuan = "tong_hop_cls",
                MaDoiTuongLienQuan = summary.MaPhieuTongHop,

                NguoiNhan = new List<NotificationRecipientCreateRequest>
                {
                    new NotificationRecipientCreateRequest
                    {
                        LoaiNguoiNhan = "nhan_vien_y_te",
                        MaNguoiNhan = null
                    }
                }
            };

            await _notifications.TaoThongBaoAsync(request);
        }

        private static string RenderThongBaoTongHopCls(ClsSummaryDto summary)
        {
            var tenBn = string.IsNullOrWhiteSpace(summary.TenBenhNhan)
                ? summary.MaBenhNhan
                : $"{summary.TenBenhNhan} ({summary.MaBenhNhan})";

            return $"Đã có phiếu tổng hợp kết quả cận lâm sàng cho bệnh nhân {tenBn}.";
        }

    }
}
