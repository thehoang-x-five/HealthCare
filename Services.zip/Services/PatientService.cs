﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HealthCare.Datas;
using HealthCare.DTOs;
using HealthCare.Entities;
using HealthCare.Realtime;
using HealthCare.RenderID;
using Microsoft.EntityFrameworkCore;

namespace HealthCare.Services
{
    public class PatientService(
     DataContext db,
     IRealtimeService realtime,
     INotificationService notifications
 ) : IPatientService
    {
        private readonly DataContext _db = db;
        private readonly IRealtimeService _realtime = realtime;
        private readonly INotificationService _notifications = notifications;

        // ============================================================
        // =   1. TẠO HOẶC CẬP NHẬT BỆNH NHÂN (CREATE / UPSERT)      =
        // ============================================================

        /// <summary>
        /// Tạo mới hoặc cập nhật bệnh nhân (theo họ tên + ngày sinh + điện thoại/email).
        /// Nếu tìm thấy record trùng => cập nhật, ngược lại => tạo mới.
        /// </summary>
        public async Task<PatientDto> TaoHoacCapNhatBenhNhanAsync(PatientCreateUpdateRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.HoTen))
                throw new ArgumentException("HoTen là bắt buộc");

            if (request.NgaySinh == default)
                throw new ArgumentException("NgaySinh là bắt buộc");

            // Heuristic tìm bệnh nhân cũ: Họ tên + Ngày sinh + SĐT (hoặc Email)
            BenhNhan? entity = null;

            if (!string.IsNullOrWhiteSpace(request.DienThoai))
            {
                var phone = request.DienThoai.Trim();
                entity = await _db.BenhNhans.FirstOrDefaultAsync(b =>
                    b.HoTen == request.HoTen &&
                    b.NgaySinh == request.NgaySinh &&
                    b.DienThoai == phone);
            }

            if (entity == null && !string.IsNullOrWhiteSpace(request.Email))
            {
                var email = request.Email.Trim();
                entity = await _db.BenhNhans.FirstOrDefaultAsync(b =>
                    b.HoTen == request.HoTen &&
                    b.NgaySinh == request.NgaySinh &&
                    b.Email == email);
            }

            var isNew = entity == null;

            if (entity == null)
            {
                entity = new BenhNhan
                {
                    MaBenhNhan = GeneratorID.NewBenhNhanId(),
                    TrangThaiTaiKhoan = "hoat_dong",
                    NgayTrangThai = DateTime.Today
                };
                _db.BenhNhans.Add(entity);
            }

            // Cập nhật thông tin hành chính
            entity.HoTen = request.HoTen;
            entity.NgaySinh = request.NgaySinh;
            entity.GioiTinh = request.GioiTinh ?? "";
            entity.DienThoai = request.DienThoai;
            entity.Email = request.Email;
            entity.DiaChi = request.DiaChi;

            // Cập nhật thông tin bệnh án
            entity.DiUng = request.DiUng;
            entity.ChongChiDinh = request.ChongChiDinh;
            entity.ThuocDangDung = request.ThuocDangDung;
            entity.TieuSuBenh = request.TieuSuBenh;
            entity.TienSuPhauThuat = request.TienSuPhauThuat;
            entity.NhomMau = request.NhomMau;
            entity.BenhManTinh = request.BenhManTinh;
            entity.SinhHieu = request.SinhHieu;

            await _db.SaveChangesAsync();

            var dto = MapToDto(entity);

            if (isNew)
            {
                await _realtime.BroadcastPatientCreatedAsync(dto);
                // 🔔 Thông báo bệnh nhân mới
                await TaoThongBaoBenhNhanMoiAsync(dto);
            }
            else
            {
                await _realtime.BroadcastPatientUpdatedAsync(dto);
                // 🔔 Thông báo cập nhật thông tin bệnh nhân
                await TaoThongBaoCapNhatBenhNhanAsync(dto);
            }

            return dto;
        }

        // ============================================================
        // =   2. LẤY THÔNG TIN CHI TIẾT BỆNH NHÂN (VIEW MODAL)      =
        // ============================================================

        /// <summary>
        /// Lấy chi tiết bệnh nhân cho PatientModal:
        /// - Thông tin hành chính + bệnh án
        /// - Trạng thái tài khoản + trong ngày
        /// - Lịch sử khám rút gọn
        /// - Lịch sử giao dịch rút gọn
        /// </summary>
        public async Task<PatientDetailDto?> LayBenhNhanAsync(string maBenhNhan)
        {
            if (string.IsNullOrWhiteSpace(maBenhNhan))
                throw new ArgumentException("maBenhNhan là bắt buộc");

            var bn = await _db.BenhNhans
                .AsNoTracking()
                .FirstOrDefaultAsync(b => b.MaBenhNhan == maBenhNhan);

            if (bn is null)
                return null;

            // Lấy lịch sử khám & giao dịch cho bệnh nhân (chạy song song)
            var visitsTask = LayLichSuKhamBenhNhanAsync(maBenhNhan);
            var txnsTask = LayLichSuGiaoDichBenhNhanAsync(maBenhNhan);

            await Task.WhenAll(visitsTask, txnsTask);

            var visits = visitsTask.Result;
            var txns = txnsTask.Result;

            var detail = new PatientDetailDto
            {
                MaBenhNhan = bn.MaBenhNhan,
                HoTen = bn.HoTen,
                NgaySinh = bn.NgaySinh,
                GioiTinh = bn.GioiTinh,
                DienThoai = bn.DienThoai,
                Email = bn.Email,
                DiaChi = bn.DiaChi,

                TrangThaiTaiKhoan = bn.TrangThaiTaiKhoan,
                TrangThaiHomNay = bn.TrangThaiHomNay,
                NgayTrangThai = bn.NgayTrangThai,

                DiUng = bn.DiUng,
                ChongChiDinh = bn.ChongChiDinh,
                ThuocDangDung = bn.ThuocDangDung,
                TieuSuBenh = bn.TieuSuBenh,
                TienSuPhauThuat = bn.TienSuPhauThuat,
                NhomMau = bn.NhomMau,
                BenhManTinh = bn.BenhManTinh,
                SinhHieu = bn.SinhHieu,

                LichSuKham = visits,
                LichSuGiaoDich = txns
            };

            return detail;
        }

        // ============================================================
        // =   3. TÌM KIẾM / DANH SÁCH BỆNH NHÂN (PAGING)            =
        // ============================================================

        public async Task<PagedResult<PatientDto>> TimKiemBenhNhanAsync(PatientSearchFilter filter)
        {
            var query = _db.BenhNhans.AsNoTracking().AsQueryable();

            if (!string.IsNullOrWhiteSpace(filter.MaBenhNhan))
            {
                query = query.Where(b => b.MaBenhNhan == filter.MaBenhNhan);
            }

            if (!string.IsNullOrWhiteSpace(filter.DienThoai))
            {
                var phone = filter.DienThoai.Trim();
                query = query.Where(b => b.DienThoai == phone);
            }

            if (!string.IsNullOrWhiteSpace(filter.GioiTinh))
            {
                query = query.Where(b => b.GioiTinh == filter.GioiTinh);
            }

            if (!string.IsNullOrWhiteSpace(filter.TrangThaiTaiKhoan))
            {
                query = query.Where(b => b.TrangThaiTaiKhoan == filter.TrangThaiTaiKhoan);
            }

            if (!string.IsNullOrWhiteSpace(filter.TrangThaiHomNay))
            {
                query = query.Where(b => b.TrangThaiHomNay == filter.TrangThaiHomNay);
            }

            if (!string.IsNullOrWhiteSpace(filter.Keyword))
            {
                var kw = filter.Keyword.Trim();
                query = query.Where(b =>
                    b.HoTen.Contains(kw) ||
                    (b.MaBenhNhan != null && b.MaBenhNhan.Contains(kw)) ||
                    (b.Email != null && b.Email.Contains(kw)) ||
                    (b.DienThoai != null && b.DienThoai.Contains(kw)));
            }

            // Sắp xếp
            var sortBy = filter.SortBy?.ToLowerInvariant();
            var sortDir = (filter.SortDirection ?? "asc").ToLowerInvariant();

            query = (sortBy, sortDir) switch
            {
                ("ngaysinh", "desc") => query.OrderByDescending(b => b.NgaySinh),
                ("ngaysinh", _) => query.OrderBy(b => b.NgaySinh),

                ("ngaytrangthai", "desc") => query.OrderByDescending(b => b.NgayTrangThai),
                ("ngaytrangthai", _) => query.OrderBy(b => b.NgayTrangThai),

                ("hoten", "desc") => query.OrderByDescending(b => b.HoTen),
                ("hoten", _) => query.OrderBy(b => b.HoTen),

                _ when sortDir == "desc" => query.OrderByDescending(b => b.HoTen),
                _ => query.OrderBy(b => b.HoTen)
            };

            var page = filter.Page <= 0 ? 1 : filter.Page;
            var pageSize = filter.PageSize <= 0 ? 50 : filter.PageSize;

            var total = await query.CountAsync();

            var list = await query
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            var items = list.Select(MapToDto).ToList();

            return new PagedResult<PatientDto>
            {
                Items = items,
                TotalItems = total,
                Page = page,
                PageSize = pageSize
            };
        }

        // ============================================================
        // =   4. CẬP NHẬT TRẠNG THÁI TRONG NGÀY CỦA BỆNH NHÂN       =
        // ============================================================

        public async Task<PatientDto?> CapNhatTrangThaiBenhNhanAsync(
            string maBenhNhan,
            PatientStatusUpdateRequest request)
        {
            var entity = await _db.BenhNhans.FirstOrDefaultAsync(b => b.MaBenhNhan == maBenhNhan);
            if (entity is null) return null;

            entity.TrangThaiHomNay = request.TrangThaiHomNay;
            entity.NgayTrangThai = DateTime.Today;

            await _db.SaveChangesAsync();

            var dto = MapToDto(entity);
            await _realtime.BroadcastPatientStatusUpdatedAsync(dto);
            // 🔔 Thông báo riêng cho việc đổi trạng thái trong ngày
            await TaoThongBaoCapNhatBenhNhanAsync(dto, laCapNhatTrangThai: true);

            return dto;
        }

        // ============================================================
        // =   5. LỊCH SỬ KHÁM BỆNH NHÂN (CHO PATIENT MODAL)         =
        // ============================================================

        /// <summary>
        /// Lịch sử khám rút gọn cho một bệnh nhân,
        /// dùng cho tab "Lịch sử khám" trong PatientModal.
        /// </summary>
        public async Task<IReadOnlyList<PatientVisitSummaryDto>> LayLichSuKhamBenhNhanAsync(
            string maBenhNhan)
        {
            if (string.IsNullOrWhiteSpace(maBenhNhan))
                throw new ArgumentException("maBenhNhan là bắt buộc");

            var q = _db.LuotKhamBenhs
                .AsNoTracking()
                .Include(l => l.HangDoi)
                    .ThenInclude(h => h.BenhNhan)
                .Include(l => l.HangDoi)
                    .ThenInclude(h => h.Phong)
                        .ThenInclude(p => p.KhoaChuyenMon)
                .Include(l => l.NhanSuThucHien)
                .Include(l => l.HangDoi)
                    .ThenInclude(h => h.PhieuKhamLamSang)
                        .ThenInclude(pk => pk.PhieuChanDoanCuoi)
                .Include(l => l.HangDoi)
                    .ThenInclude(h => h.PhieuKhamLamSang)
                        .ThenInclude(pk => pk.DichVuKham)
                .Where(l => l.HangDoi.MaBenhNhan == maBenhNhan);

            var list = await q
                .OrderByDescending(l => l.ThoiGianBatDau)
                .ThenByDescending(l => l.MaLuotKham)
                .Take(50) // giới hạn 50 lượt gần nhất cho modal
                .ToListAsync();

            return list.Select(MapToVisitSummary).ToList();
        }

        // ============================================================
        // =   6. LỊCH SỬ GIAO DỊCH BỆNH NHÂN (CHO PATIENT MODAL)    =
        // ============================================================

        /// <summary>
        /// Lịch sử giao dịch rút gọn cho một bệnh nhân,
        /// dùng cho tab "Giao dịch" trong PatientModal.
        /// </summary>
        public async Task<IReadOnlyList<PatientTransactionSummaryDto>> LayLichSuGiaoDichBenhNhanAsync(
            string maBenhNhan)
        {
            if (string.IsNullOrWhiteSpace(maBenhNhan))
                throw new ArgumentException("maBenhNhan là bắt buộc");

            var q = _db.HoaDonThanhToans
                .AsNoTracking()
                .Where(h => h.MaBenhNhan == maBenhNhan);

            var list = await q
                .OrderByDescending(h => h.ThoiGian)
                .ThenByDescending(h => h.MaHoaDon)
                .Take(50)
                .ToListAsync();

            return [.. list.Select(MapToTransactionSummary)];
        }

        // ============================================================
        // =                     HELPER MAPPERS                       =
        // ============================================================

        private static PatientDto MapToDto(BenhNhan b)
        {
            return new PatientDto
            {
                MaBenhNhan = b.MaBenhNhan,
                HoTen = b.HoTen,
                NgaySinh = b.NgaySinh,
                GioiTinh = b.GioiTinh,
                DienThoai = b.DienThoai,
                Email = b.Email,
                DiaChi = b.DiaChi,
                TrangThaiHomNay = b.TrangThaiHomNay,
                NgayTrangThai = b.NgayTrangThai
            };
        }

        private static PatientVisitSummaryDto MapToVisitSummary(LuotKhamBenh luot)
        {
            var h = luot.HangDoi;
            var phong = h.Phong;
            var khoa = phong.KhoaChuyenMon;
            var bs = luot.NhanSuThucHien;
            var phieuLs = h.PhieuKhamLamSang;
            var pcd = phieuLs?.PhieuChanDoanCuoi;
            var phieuCls = phieuLs?.PhieuKhamCanLamSang;

            bool laDichVu = phong.LoaiPhong == "phong_dich_vu";
            string loaiLuot = laDichVu ? "service" : "clinic";

            string? note = pcd?.ChanDoanCuoi
                           ?? pcd?.NoiDungKham
                           ?? phieuLs?.TrieuChung;

            var dept = $"{khoa.TenKhoa} / {phong.TenPhong}";

            return new PatientVisitSummaryDto
            {
                Date = luot.ThoiGianBatDau,
                Dept = dept,
                Doctor = bs?.HoTen ?? string.Empty,
                Note = note,
                Type = loaiLuot,
                By = bs?.HoTen ?? string.Empty,
                Ref = phieuLs?.MaPhieuKham ?? phieuCls?.MaPhieuKhamCls ?? luot.MaLuotKham,
                MaLuotKham = luot.MaLuotKham,
                MaPhieuKham = phieuLs?.MaPhieuKham
            };
        }

        private static PatientTransactionSummaryDto MapToTransactionSummary(HoaDonThanhToan h)
        {
            var content = string.IsNullOrWhiteSpace(h.NoiDung)
                ? $"{h.LoaiDotthu} - {h.SoTien:n0}đ"
                : h.NoiDung;

            return new PatientTransactionSummaryDto
            {
                Date = h.ThoiGian,
                Item = content,
                Amount = h.SoTien,
                Status = h.TrangThai,
                Ref = h.MaHoaDon,
                MaHoaDon = h.MaHoaDon,
                LoaiDotThu = h.LoaiDotthu,
                PhuongThucThanhToan = h.PhuongThucThanhToan
            };
        }
        private async Task TaoThongBaoBenhNhanMoiAsync(PatientDto bn)
        {
            if (bn == null) return;

            var title = "Bệnh nhân mới";
            var body =
                $"Bệnh nhân mới: {bn.HoTen} (Mã: {bn.MaBenhNhan}).";

            var request = new NotificationCreateRequest
            {
                LoaiThongBao = "benh_nhan",
                TieuDe = title,
                NoiDung = body,
                MucDoUuTien = "normal",

                // Hiện DB ThongBaoHeThong chưa có FK MaBenhNhan, nên NguonLienQuan/ MaDoiTuongLienQuan
                // chủ yếu phục vụ FE về sau (không ảnh hưởng logic hiện tại).
                NguonLienQuan = "benh_nhan",
                MaDoiTuongLienQuan = bn.MaBenhNhan,

                // Gửi broadcast cho toàn bộ nhân sự y tế
                NguoiNhan = new List<NotificationRecipientCreateRequest>
                {
                    new NotificationRecipientCreateRequest
                    {
                        LoaiNguoiNhan = "nhan_vien_y_te",
                        MaNguoiNhan = null
                    }
                }
            };

            await _notifications.TaoThongBaoAsync(request);
        }

        private async Task TaoThongBaoCapNhatBenhNhanAsync(
            PatientDto bn,
            bool laCapNhatTrangThai = false)
        {
            if (bn == null) return;

            var title = laCapNhatTrangThai
                ? "Cập nhật trạng thái bệnh nhân"
                : "Cập nhật thông tin bệnh nhân";

            var body = laCapNhatTrangThai
                ? $"Trạng thái trong ngày của bệnh nhân {bn.HoTen} (Mã: {bn.MaBenhNhan}) đã được cập nhật."
                : $"Thông tin bệnh nhân {bn.HoTen} (Mã: {bn.MaBenhNhan}) đã được cập nhật.";

            var request = new NotificationCreateRequest
            {
                LoaiThongBao = "benh_nhan",
                TieuDe = title,
                NoiDung = body,
                MucDoUuTien = "normal",
                NguonLienQuan = "benh_nhan",
                MaDoiTuongLienQuan = bn.MaBenhNhan,
                NguoiNhan = new List<NotificationRecipientCreateRequest>
                {
                    new NotificationRecipientCreateRequest
                    {
                        LoaiNguoiNhan = "nhan_vien_y_te",
                        MaNguoiNhan = null
                    }
                }
            };

            await _notifications.TaoThongBaoAsync(request);
        }

    }
}
